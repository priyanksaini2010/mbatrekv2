<?php echo $this->renderPartial('pages/_banner_area'); ?>
<?php $this->setPageTitle('Copyright'); ?>
<section class="policy_container">
    <div class="container">
        <div class="main_heading">
            <h4>Copyright</h4>
            <h3 class="text_right">Copyright Notice</h3>
        </div>
        <div class="plocies_text ">
            <p>Copyright © [YEAR(S) OF FIRST PUBLICATION - E.G. “2001-2111”] [NAME - MBAtrek Pvt. Ltd.]</p>
            <h3>Credit</h3>
            <p>This document was created using a Contractology template available at <a class="link_text" href="http://www.contractology.com" target="_blank" >http://www.contractology.com</a>.</p>
            <h3>Ownership of copyright</h3>
            <p>The copyright in this website and the material on this website (including without limitation the text, computer code, artwork, photographs, images, music, audio material, video material and audio-visual material on this website) is owned by MBAtrek Pvt. Ltd. [and its licensors].</p>
            <h3>Copyright license</h3>
            <p>MBAtrek Pvt. Ltd. grants to you a worldwide non-exclusive royalty-free revocable license to:</p>
            <div class="second_details">
                <ul class="list-unstyled ">
                    <li><p>view this website and the material on this website on a computer or mobile device via a web browser;</p></li>
                    <li><p>copy and store this website and the material on this website in your web browser cache memory; and</p></li>
                    <li><p>print pages from this website for your own [personal and non-commercial] use.</p></li>
                </ul>
            </div>
            <p>MBAtrek Pvt. Ltd. does not grant you any other rights in relation to this website or the material on this website.   In other words, all other rights are reserved. </p>
            <p>For the avoidance of doubt, you must not adapt, edit, change, transform, publish, republish, distribute, redistribute, broadcast, rebroadcast or show or play in public this website or the material on this website (in any form or media) without MBAtrek Pvt. Ltd.’s prior written permission.</p>
            <h3>Data mining</h3>
            <p>The automated and/or systematic collection of data from this website is prohibited.</p>
            <h3>Permissions</h3>
            <p>You may request permission to use the copyright materials on this website by writing to <span>alok.srivastava@mbatrek.com</span></p>
            <h3>Enforcement of copyright</h3>
            <p>MBAtrek Pvt. Ltd. takes the protection of its copyright very seriously.</p>
            <p>If MBAtrek Pvt. Ltd. discovers that you have used its copyright materials in contravention of the license above, MBAtrek Pvt. Ltd. may bring legal proceedings against you seeking monetary damages and an injunction to stop you using those materials.  You could also be ordered to pay legal costs.</p>
            <p>If you become aware of any use of MBAtrek Pvt. Ltd.’s copyright materials that contravenes or may contravene the license above, please report this by email to alok.srivastava@mbatrek.com or by post to MBAtrek Pvt Ltd, 414, Suncity Business Towers, Golf Course Road, Sector -54, Gurgaon -122003, Haryana, India.</p>
            <h3>Infringing material</h3>
            <p>If you become aware of any material on the website that you believe infringes your or any other person's copyright, please report this by email to alok.srivastava@mbatrek.com] or by post to MBAtrek Pvt Ltd, 414, Suncity Business Towers, Golf Course Road, Sector -54, Gurgaon -122003, Haryana, India.</p>
            <div class="creadit_container">
                <p>You must retain the "Credit" section in this document. If you wish to use the document without the "Credit" section (e.g. to project a more professional image) then you can get a license to do so here:</p>
                <div class="clearfix"></div>
                <a target="_blank" href="http://www.contractology.com/free-document-license-copyright-notice.html">http://www.contractology.com/free-document-license-copyright-notice.html</a>
                <p>It is an infringement of our copyright to use the document without the "Credit" section and without paying the license fee.</p>
            </div>
        </div>
    </div>
</section>