<?php echo $this->renderPartial('pages/_banner_area'); ?>
<?php $this->setPageTitle('What We Do');?>
<section class="bielf_container what_we_do">
    <div class="container">
        <div class="main_heading">
            <h4>What We Do</h4>
            <h3>What we do Differently</h3>
        </div>
        <p class="blf_text">At MBAtrek Pvt. Ltd., we are committed to fostering Character, Hope, Attitude, Skills and Enthusiasm through our following modules</p>
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="do_img">
                    <img class="img-responsive" src="images/do_img_left.png">
                </div>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="do_img">
                    <img class="img-responsive" src="images/do_imgrightt.png">
                </div>
            </div>
        </div>
        <p class="do_text">We have designed an end- to- end solution for students with a synthesized program going hand in hand with the faculty and placement cells of the university. Our interface with the institute and students will begin right from when the students are admitted and follow them through up to the time they are rightly placed. MBAtrek will take a step forward to further provide students with support and mentoring for their first year on the job. </p>
        <p class="do_text">For the entire 2- year master’s program, we will extend on- campus training to students and in addition we will deliver our modules through webinars, electronic media, presentations, mobile App and web portal.</p>
        <p class="do_text">With the intention of being approachable and accessible, we have designed our web portal for all our stakeholders, hence ensuring visibility, coordination and communication.
            We fundamentally stand for a strong Industry- Interaction of institutes. For this purpose, we leverage our network of industrial contacts within companies to increase opportunities for more live Projects, Internships & eventual placements. We are equally going to work with the industry partner companies to sensitize them to invest their time and effort at universities. </p>
        <p class="do_text">Our standard registered program modules:</p>
        <div class="row second_do_img">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="do_img">
                    <ul class="list-unstyled list_icn">
                        <li>- LeapFWD</li>
                        <li>- SkillUP</li>
                        <li>- InCube</li>
                        <li>- Cracknack</li>
                        <li>- LedXemplary</li>
                        <li>- GoConsult</li>
                        <li>- InterACE</li>
                        <li>- InterPRO</li>
                        <li>- InterARISE</li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="do_img">
                    <img class="img-responsive" src="images/do_btm.png">
                </div>
            </div>
        </div>
    </div>
</section>