<section class="banner_area">
    <div class="container">
        <h2>You are always a student, never a master. You have to keep moving forward</h2>
        <span>- Conrad Hall</span>
    </div>
</section>  
<section class="bielf_container student_benifits">
    <div class="container">
        <div class="main_heading">
            <h4>Benefits</h4>
            <h3>MBA Students - What’s There For Me?</h3>
        </div> 
        <div class="center_benifits">
            <img class="img-responsive" src="images/logo_tansparent.png"> 
            <div class="benifits_box">
                <h3>Our Student Benefits</h3>
                <ul>
                    <li><p>Decision maker</p></li>
                    <li><p>Creative & problem solver</p></li>
                    <li><p>High on character, ethics and corporate values</p></li>
                    <li><p>Leader & Team Player</p></li>
                    <li><p>Courageous, motivated and willing to take challenges</p></li>
                    <li><p>Analytical thinker and able to relate to strategy</p></li>
                    <li><p>Global ‘mind - set’</p></li>
                    <li><p>Customer focussed</p></li>
                    <li><p>Able to apply theoretical knowledge to practical situation</p></li>
                    <li><p>‘Giver’ - the Philanthropist</p></li>
                </ul>
            </div>
            <div class="left_benifits_bx first_bx">
                <h3>Character building, developing attitude, skills, spiralling hope & enthusiasm</h3>
            </div>
            <div class="left_benifits_bx yello_box">
                <h3>Imparting industry knowledge & management practices and tools</h3>
            </div>
            <div class="left_benifits_bx grey_box">
                <h3>- Business etiquettes</br>
                    - Work place behaviour</br>
                    - Ethics</br>
                    - Values of corporate world</br>
                    - Enhancing soft skills
                </h3>
            </div>
            <div class="left_benifits_bx dark_yellow">
                <h3>Delivering global industry learnings and best business practices</h3>
            </div>
            <div class="left_benifits_bx green_bx">
                <h3>Mentoring ‘Intern - ACE / ARISE / PRO’</br>
                    -  Internship</br>
                    -  1st Year on job
                </h3>
            </div>
            <div class="left_benifits_bx blue_bx">
                <h3>Trained to undertake Company / Industry research analysis</h3>
            </div>
        </div>
    </div>
</section>