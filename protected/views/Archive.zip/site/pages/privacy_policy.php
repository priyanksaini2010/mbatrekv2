<?php echo $this->renderPartial('pages/_banner_area'); ?>
<?php $this->setPageTitle('Privacy Policy'); ?>
<section class="policy_container">
    <div class="container">
        <div class="main_heading">
            <h4>Privacy Policy</h4>
            <h3 class="text_right">Our Privacy Policy</h3>
        </div>
        <div class="plocies_text ">
            <p>Your privacy is important to MBAtrek Pvt. Ltd.  This privacy statement provides information about the personal information that MBAtrek Pvt. Ltd. collects, and the ways in which MBAtrek Pvt. Ltd. uses that personal information.</p>
            <h3>Credit</h3>
            <p>This document was created using a Contractology template available at <a class="link_text" href="http://www.contractology.com" target="_blank" >http://www.contractology.com</a>.</p>
            <h3>Personal information collection</h3>
            <p>MBAtrek Pvt. Ltd. may collect and use the following kinds of personal information: </p>
            <div class="second_details">
                <ul class="list-unstyled ">
                    <li><p>information about your use of this website </p></li>
                    <li><p>information that you provide using for the purpose of registering with the website</p></li>
                    <li><p>information about transactions carried out over this website</p></li>
                    <li><p>information that you provide for the purpose of subscribing to the website services</p></li>
                    <li><p>any other information that you send to MBAtrek Pvt. Ltd.</p></li>
                </ul>
            </div>
            <h3>Using personal information</h3>
            <p>MBAtrek Pvt. Ltd. may use your personal information to: </p>
            <div class="second_details">
                <ul class="list-unstyled ">
                    <li><p>administer this website; </p></li>
                    <li><p>personalize the website for you;</p></li>
                    <li><p>enable your access to and use of the website services;</p></li>
                    <li><p>publish information about you on the website;</p></li>
                    <li><p>send to you products that you purchase;</p></li>
                    <li><p>supply to you services that you purchase;</p></li>
                    <li><p>send to you statements and invoices;</p></li>
                    <li><p>collect payments from you; and</p></li>
                    <li><p>send you marketing communications.</p></li>
                </ul>
            </div>
            <p>Where MBAtrek Pvt. Ltd. discloses your personal information to its agents or sub-contractors for these purposes, the agent or sub-contractor in question will be obligated to use that personal information in accordance with the terms of this privacy statement. </p>
            <p>In addition to the disclosures reasonably necessary for the purposes identified elsewhere above, MBAtrek Pvt. Ltd. may disclose your personal information to the extent that it is required to do so by law, in connection with any legal proceedings or prospective legal proceedings, and in order to establish, exercise or defend its legal rights.</p>
            <h3>Securing your data</h3>
            <p>MBAtrek Pvt. Ltd. will take reasonable technical and organisational precautions to prevent the loss, misuse or alteration of your personal information. </p>
            <p>MBAtrek Pvt. Ltd. will store all the personal information you provide.</p>
            <h3>Cross-border data transfers</h3>
            <p>Information that MBAtrek Pvt. Ltd. collects may be stored and processed in and transferred between any of the countries in which MBAtrek Pvt. Ltd. operates to enable the use of the information in accordance with this privacy policy.</p>
            <p>In addition, personal information that you submit for publication on the website will be published on the internet and may be available around the world.You agree to such cross-border transfers of personal information.</p>
            <h3>Updating this statement</h3>
            <p>MBAtrek Pvt. Ltd. may update this privacy policy by posting a new version on this website.  </p>
            <p>You should check this page occasionally to ensure you are familiar with any changes.  </p>
            <h3>Other websites</h3>
            <p class="website_Text">This website contains links to other websites.  </p>
            <p>MBAtrek Pvt. Ltd. is not responsible for the privacy policies or practices of any third party.</p>
            <h3 class="company_text">Contact MBAtrek Pvt. Ltd.</h3>
            <p>If you have any questions about this privacy policy or MBAtrek Pvt. Ltd.’s treatment of your personal information, please write:</p>
            <div class="second_details">
                <ul class="list-unstyled ">
                    <li><p>by email to alok.srivastava@mbatrek.com; or  </p></li>
                    <li><p>by post to MBAtrek Private Ltd. 414, Suncity Business Towers, Golf Course Road, Sector-54, Gurgaon, Haryana-122003. India</p></li>
                </ul>
            </div>
            <div class="creadit_container">
                <p>You must retain the "Credit" section in this document. If you wish to use the document without the "Credit" section (e.g. to project a more professional image) then you can get a license to do so here:</p>
                <div class="clearfix"></div>
                <a target="_blank" href="http://www.contractology.com/free-document-license-privacy-statement.html">http://www.contractology.com/free-document-license-privacy-statement.html</a>
                <p>It is an infringement of our copyright to use the document without the "Credit" section and without paying the license fee.</p>
            </div>
        </div>
    </div>
</section>