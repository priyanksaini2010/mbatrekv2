<?php echo $this->renderPartial('pages/_banner_area'); ?>
<?php $this->setPageTitle('Our Belief');?>
<section class="bielf_container">
    <div class="container">
        <div class="main_heading">
            <h4>Our Belief</h4>
            <h3>What We Believe</h3>
        </div>
        <p class="blf_text">MBAtrek is committed to balance a curriculum - driven program for transforming students into Industry ‘ready & relevant’ to ‘hit the ground running’</p>
        <div class="main_heading">
            <h4>Our Values</h4>
            <h3>What we stand for</h3>
        </div>
        <div class="blif_listing_Text">
            <div class="row">
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="blf_block">
                        <h2>Partnership in Success</h2>
                        <p>We measure our success through the success of our stakeholders (Student, Institutes, Industry)</p>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="blf_block">
                        <h2>Framework enabling synergy within stakeholders</h2>
                        <p>We create framework, coursework and environment that enables learning of effective and current industry best practices for students and trust- based, sustainable industry - institute partnership</p>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="blf_block">
                        <h2>Chasing the CHASE (Character, Hope, Attitude, Skill, Enthusiasm) values</h2>
                        <p>We will exhibit exemplary Character, Hope, Attitude, Skill and Enthusiasm while delivering world- class MBAtrek, Mtrek, and GradXplore programs</p>
                    </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-12">
                    <div class="blf_block">
                        <h2>Creating value through responsible, innovative & global program delivery</h2>
                        <p>We will be highly responsible, innovative and global in our program delivery while working with business managers to create significant value for the corporates through our three flagship programs</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="blf_img">
            <img class="img-responsive" src="images/our-belief-img.png">
        </div>
    </div>
</section>