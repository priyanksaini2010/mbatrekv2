<?php echo $this->renderPartial('pages/_banner_area'); ?>
<?php $this->setPageTitle('Quick Links'); ?>
<section class="bielf_container quick_link">
    <div class="container">
        <div class="main_heading">
            <h4>Quick Links</h4>
            <h3>Quick Links To Navigate</h3>
        </div>
        <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="left_links">
                    <h2>Industry</h2>
                    <ul class="list-unstyled">
                        <h3>Post</h3>
                        <li><a href="javascript:void(0);">- Live Project</a></li>
                        <li><a href="javascript:void(0);">- Internship</a></li>
                        <li><a href="javascript:void(0);">- Job</a></li>
                    </ul>
                    <ul class="list-unstyled">
                        <h3>Session</h3>
                        <li><a href="javascript:void(0);">- Hold A Session At Campus</a></li>
                    </ul>
                    <ul class="list-unstyled">
                        <h3>Consulting</h3>
                        <li><a href="javascript:void(0);">- Assign Consulting Project With Faculty</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-12">
                <div class="right_links">
                    <h2>Institute</h2>
                    <ul class="list-unstyled">
                        <li><a href="javascript:void(0);">- Feedback of MBAtrek to Students</a></li>
                        <li><a href="javascript:void(0);">- Rating Given By MBA Students to MBAtrek</a></li>
                        <li><a href="javascript:void(0);">- Attendance</a></li>
                        <li><a href="javascript:void(0);">- Score</a></li>
                        <li><a href="javascript:void(0);">- Talk To Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>