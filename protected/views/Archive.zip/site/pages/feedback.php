<?php $this->setPageTitle('Feedback');?>
<?php echo $this->renderPartial('pages/_banner_area'); ?>  
<section class="contact_container">
    <div class="container">
        <div class="main_heading">
            <h4>Feedback</h4>
            <h3>Give Your Feedback</h3>
        </div>
        <div class="contact_form fee_Text">
            <p>Send us any comments, feedback, suggestions or problems you have encountered regarding our services so that we can fix them right away.</p>
        </div>
        <div class="get_in_touch">
            <div class="request_form feedback_form">
                <form class="form-horizontal" action='' method="POST">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="phAnimate">
                            <label for="firstname">Your Message <em>*</em></label>
                            <textarea></textarea>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="phAnimate">
                            <label for="firstname">Email ID (optional - if you require a response)</label>
                            <input type="text" class="input_field" id="Email">
                        </div>
                    </div>
                    <div class="sibmit_form">
                        <button class="site_btn raised ripple" type="submit"><a href="">Submit</a></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>