<?php echo $this->renderPartial('pages/_banner_area'); ?>
<?php $this->setPageTitle('Student6 Register'); ?>
<section class="login_container">
    <div class="container">
        <div class="login_outer">
            <div class="login_login signup">
                <img src="images/footer_logo.png"/>
                <div class="logo_line"></div>
            </div>
            <div class="sign_up_div">
                <h2>MBA Student </br> REGISTER & Varify</h2>
                <form class="form-horizontal" action='' method="POST">
                    <div class="phAnimate">
                        <label for="firstname">Email <em>*</em></label>
                        <input type="text" class="input_field" id="Email">
                    </div>
                    <div class="phAnimate">
                        <label for="lastname">First Name <em>*</em></label>
                        <input type="text" class="input_field" id="Password">
                    </div>
                    <div class="phAnimate">
                        <label for="lastname">Last Name <em>*</em></label>
                        <input type="text" class="input_field" id="Password">
                    </div>
                    <div class="phAnimate calender">
                        <span>D.O.B- 00/00/0000 <em>*</em></span>
                        <label for="lastname">D.O.B- 00/00/0000 <em>*</em></label>
                        <input type="text" class="input_field date_calender" id="Password">
                    </div>
                    <div class="phAnimate">
                        <label for="lastname">Institute’s E-mail ID <em>*</em></label>
                        <input type="text" class="input_field" id="Password">
                    </div>
                    <div class="optional_div">
                        <div class="main_option">
                            <h3>Optional</h3>
                        </div>
                        <div class="phAnimate">
                            <label for="lastname">Institute </label>
                            <input type="text" class="input_field" id="Password">
                        </div>
                        <div class="phAnimate">
                            <label for="lastname">City </label>
                            <input type="text" class="input_field" id="Password">
                        </div>
                        <div class="phAnimate">
                            <label for="lastname">Program </label>
                            <input type="text" class="input_field" id="Password">
                        </div>
                        <div class="phAnimate">
                            <label for="lastname">Batch </label>
                            <input type="text" class="input_field" id="Password">
                        </div>
                        <div class="btton_field">
                            <button type="submit" class="yello_btn raised ripple" >REGISTER HERE</button>
                        </div>
                    </div>
                </form> 
            </div>
        </div>
    </div>	
</section>