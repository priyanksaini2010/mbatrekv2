<?php echo $this->renderPartial('pages/_banner_area'); ?>
<?php $this->setPageTitle('Disclaimer'); ?>
<section class="policy_container">
    <div class="container">
        <div class="main_heading">
            <h4>Disclaimer</h4>
            <h3 class="text_right">Disclaimer</h3>
        </div>
        <div class="plocies_text ">
            <h3>Credit</h3>
            <p>This document was created using a Contractology template available at <a class="link_text" href="http://www.contractology.com" target="_blank" >http://www.contractology.com</a>.</p>
            <h3>No warranties</h3>
            <p>This website is provided “as is” without any representations or warranties, express or implied.  MBAtrek Pvt. Ltd. makes no representations or warranties in relation to this website or the information and materials provided on this website.  </p>
            <p>Without prejudice to the generality of the foregoing paragraph, MBAtrek Pvt. Ltd. does not warrant that:</p>
            <div class="second_details">
                <ul class="list-unstyled ">
                    <li><p>this website will be constantly available, or available at all; or</p></li>
                    <li><p>the information on this website is complete, true, accurate or non-misleading.</p></li>
                </ul>
            </div>
            <p>Nothing on this website constitutes, or is meant to constitute, advice of any kind. If you require advice in relation to any legal, financial or medical matter you should consult an appropriate professional.</p>
            <h3>Limitations of liability</h3>
            <p>MBAtrek Pvt. Ltd. will not be liable to you whether under the law of contract, the law of torts or otherwise in relation to the contents of, or use of, or otherwise in connection with, this website:</p>
            <div class="second_details">
                <ul class="list-unstyled ">
                    <li><p>for any indirect, special or consequential loss; or</p></li>
                    <li><p>for any business losses, loss of revenue, income, profits or anticipated savings, loss of contracts or business relationships, loss of reputation or goodwill, or loss or corruption of information or data.</p></li>
                </ul>
            </div>
            <p>These limitations of liability apply even if MBAtrek Pvt. Ltd. has been expressly advised of the potential loss.</p>
            <h3>Exceptions</h3>
            <p>Nothing in this website disclaimer will exclude or limit any warranty implied by law that it would be unlawful to exclude or limit; and nothing in this website disclaimer will exclude or limit MBAtrek Pvt. Ltd.’s liability in respect of any:</p>
            <div class="second_details">
                <ul class="list-unstyled ">
                    <li><p>death or personal injury caused by MBAtrek Pvt. Ltd.’s negligence;</p></li>
                    <li><p>fraud or fraudulent misrepresentation on the part of MBAtrek Pvt. Ltd.; or</p></li>
                    <li><p>matter which it would be illegal or unlawful for MBAtrek Pvt. Ltd. to exclude or limit, or to attempt or purport to exclude or limit, its liability. </p></li>
                </ul>
            </div>
            <h3>Reasonableness</h3>
            <p>By using this website, you agree that the exclusions and limitations of liability set out in this website disclaimer are reasonable. If you do not think they are reasonable, you must not use this website.</p>
            <h3>Other parties</h3>
            <p>You accept that, as a limited liability entity, MBAtrek Pvt. Ltd. has an interest in limiting the personal liability of its officers and employees.  You agree that you will not bring any claim personally against MBAtrek Pvt. Ltd.’s officers or employees in respect of any losses you suffer in connection with the website.</p>
            <p>Without prejudice to the foregoing paragraph, you agree that the limitations of warranties and liability set out in this website disclaimer will protect MBAtrek Pvt. Ltd.’s officers, employees, agents, subsidiaries, successors, assigns and sub-contractors as well as MBAtrek Pvt. Ltd. </p>
            <h3>Unenforceable provisions</h3>
            <p>If any provision of this website disclaimer is, or is found to be, unenforceable under applicable law, that will not affect the enforceability of the other provisions of this website disclaimer.</p>
            <div class="creadit_container">
                <p>You must retain the "Credit" section in this document. If you wish to use the document without the "Credit" section (e.g. to project a more professional image) then you can get a license to do so here:</p>
                <div class="clearfix"></div>
                <a target="_blank" href="http://www.contractology.com/free-document-license-website-disclaimer.html">http://www.contractology.com/free-document-license-website-disclaimer.html</a>
                <p>It is an infringement of our copyright to use the document without the "Credit" section and without paying the license fee.</p>
            </div>
        </div>
    </div>
</section>