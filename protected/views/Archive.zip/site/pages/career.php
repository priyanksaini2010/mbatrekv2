<?php echo $this->renderPartial('pages/_banner_area'); ?>
<?php $this->setPageTitle('Career');?>
<section class="bielf_container carrer_block">
    <div class="container">
        <div class="main_heading">
            <h4>Careers</h4>
            <h3>Careers at MBAtrek</h3>
        </div> 
        <h3 class="career_text"><span>The Rewarding Career</span> You Are Looking For Is At MBAtrek</h3> 
    </div>
    <div class="career_container">
        <img src="images/career_banner.png"/>
        <h3 class="career_text"><span>The Rewarding Career</span> You Are Looking For Is At MBAtrek</h3>
    </div> 
    <div class="container">
        <div class="career_Steps">
            <div class="career_stps_blk">
                <h3>MBAtrek Is </br>Globaly Unique</h3>
            </div>
            <div class="career_stps_blk2">
                <h3>We offer ‘end-to-end’ solution to Institutes & Industry</h3>
            </div>
            <div class="career_stps_blk3">
                <h3>We create life-long impact on the mind-set & capabilities of students</h3>
            </div>
            <div class="career_stps_blk4">
                <h3>We build Character, Hope, Attitude, Skill & Enthusiasm</h3>
            </div>
        </div>
        <div class="cant_wait">
            <h3>We Can’t wait to meet you</h3>
            <div class="main_register"><div class="site_btn"><a class="raised ripple" href="javascript:void(0);">Search Open Positions</a></div></div>
        </div>

    </div>
</section>