<section class="banner_area">
    <div class="container">
        <h2>You are always a student, never a master. You have to keep moving forward</h2>
        <span>- Conrad Hall</span>
    </div>
</section>  
<section class="bielf_container">
    <div class="container">
        <div class="main_heading">
            <h4>Benefits</h4>
            <h3>What’s There For My Institute?</h3>
        </div> 
        <div class="center_benifits">
            <img class="img-responsive" src="images/logo_tansparent.png"> 
            <div class="benifits_box">
                <h3>Our Institute Benefits</h3>
                <ul>
                    <li><p>Global Industry Standard Program: joint effort of institute and MBAtrek.</p></li>
                    <li><p>Uplifting the Character, Attitude, Hope, Skills and Enthusiasm of students to contribute to society</p></li>
                    <li><p>An environment engaging high calibre faculty to teach, research and develop industry interfaced case studies. </p></li>
                </ul>
            </div>
            <div class="left_benifits_bx first_bx">
                <h3>Transmitting industry knowledge and experience to faculty, placement cell and management of the institute.</h3>
            </div>
            <div class="left_benifits_bx yello_box">
                <h3>Updating the institute with most current global business practises to enable faculty to merge current global trends in their deliverables.</h3>
            </div>
            <div class="left_benifits_bx grey_box">
                <h3>Investment of time and effort beyond academics in building an efficient and productive student with a corporate “mind-set” and ethics.</h3>
            </div>
            <div class="left_benifits_bx dark_yellow">
                <h3>Support placement cell to get major corporates to visit the campus.</h3>
            </div>
            <div class="left_benifits_bx green_bx">
                <h3>Enhance industry interaction - invite “Live Projects”, Internship and Final Placement.</h3>
            </div>
            <div class="left_benifits_bx blue_bx">
                <h3>- Improve “Quality” of placement</br>
                    - This attracts high calibre students to apply</br>
                    - Enables the institute to have a choice in selecting candidates.</br>
                    - Resultantly, institute is able to fix appropriate fees in line with the value delivered</h3>
            </div>
        </div>
    </div>
</section>