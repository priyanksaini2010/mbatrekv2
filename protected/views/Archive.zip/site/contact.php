<?php $this->setPageTitle('Contact Us'); ?>
<?php echo $this->renderPartial('pages/_banner_area'); ?>  
<section class="contact_container">
    <div class="container">
        <div class="main_heading">
            <h4>Contact Us</h4>
            <h3>Contact Us for help</h3>
        </div>
        <div class="contact_form">
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque maximus facilisis ultrices. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Fusce vehicula vehicula quam id ultricies. Vivamus arcu metus, sodales vel mi nec, hendrerit vestibulum felis. Morbi mollis velit at metus vehicula convallis. Aliquam nisi lacus, rhoncus eget scelerisque in, ornare a metus.</p>
        </div>
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form_wrpper">
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="form_block">
                        <div class="icon_form">
                            <i class="fa fa-map-marker" aria-hidden="true"></i>
                        </div>
                        <div class="icon_Details">
                            <p>MBAtrek Pvt. Ltd.</br> 414, 4th floor, Suncity Business Towers </br>Golf Course Road, Sector 54, </br>Gurgaon, Haryana, 122003</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="form_block">
                        <div class="icon_form">
                            <i class="fa fa-envelope" aria-hidden="true"></i>
                        </div>
                        <div class="icon_Details">
                            <p>contact@mbatrek.com</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-12">
                    <div class="form_block">
                        <div class="icon_form">
                            <i class="fa fa-phone" aria-hidden="true"></i>
                        </div>
                        <div class="icon_Details">
                            <p>9821948334 </br>9821948334</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="get_in_touch">
            <div class="main_heading">
                <h4>Get In Touch</h4>
                <h3>Request A Call Back</h3>
            </div>
            <div class="request_form">
                <form class="form-horizontal" action='' method="POST">
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="phAnimate">
                            <label for="firstname">Your Name <em>*</em></label>
                            <input type="text" class="input_field" id="Email">
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="phAnimate">
                            <label for="firstname">Phone No. <em>*</em></label>
                            <input type="text" class="input_field" id="Email">
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="phAnimate">
                            <label for="firstname">Email ID <em>*</em></label>
                            <input type="text" class="input_field" id="Email">
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <div class="phAnimate">
                            <label for="firstname">Subject <em>*</em></label>
                            <input type="text" class="input_field" id="Email">
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-6 col-xs-12">
                        <ul class="list-inline list-unstyled chec_filed">
                            <li>
                                <input type="checkbox" name="Industry" id="Industry" class="css-checkbox" />
                                <label for="Industry" class="css-label">Industry</label>
                            </li>
                            <li>
                                <input type="checkbox" name="Institute" id="Institute" class="css-checkbox" />
                                <label for="Institute" class="css-label">Institute</label>
                            </li>
                            <li>
                                <input type="checkbox" name="Student" id="Student" class="css-checkbox" />
                                <label for="Student" class="css-label">Student</label>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="phAnimate">
                            <label for="firstname">Subject <em>*</em></label>
                            <textarea></textarea>
                        </div>
                    </div>
                    <div class="sibmit_form">
                        <button class="site_btn raised ripple" type="submit"><a href="">Submit</a></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>