<?php

class IndustryController extends Controller {

    public $errors = array();
    public $success = array();
    /**
     * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
     * using two-column layout. See 'protected/views/layouts/column2.php'.
     */
    public $layout = '//layouts/column2';

    /**
     * @return array action filters
     */
    public function filters() {
        return array(
            'accessControl', // perform access control for CRUD operations
        );
    }

    /**
     * Specifies the access control rules.
     * This method is used by the 'accessControl' filter.
     * @return array access control rules
     */
    public function accessRules() {
        return array(
            array('allow', // allow all users to perform 'index' and 'view' actions
                'actions' => array('index', 'view'),
                'users' => array('*'),
            ),
            array('allow', // allow authenticated user to perform 'create' and 'update' actions
                'actions' => array('portal', 'createintership', 'createproject', 'createjobs','createconsultingprojects'),
                'users' => array('@'),
            ),
            array('allow', // allow admin user to perform 'admin' and 'delete' actions
                'actions' => array(),
                'users' => array('admin'),
            ),
            array('deny', // deny all users
                'users' => array('*'),
            ),
        );
    }

    public function actionPortal() {
        $data = array();
        $userData = Users::model()->findByAttributes(array("id" => Yii::app()->user->id));
        
        $data['modules'] = Module::model()->findAll();
        $industryProfile =  IndustryUser::model()->findByAttributes(array("user_id" => Yii::app()->user->id));
        $data['internships'] = IndustryInternship::model()->findAllByAttributes(array("industry_id" => $industryProfile->industry_id));
        $data['projects'] = LiveProjects::model()->findAllByAttributes(array("industry_id" => $industryProfile->industry_id));
        $data['jobs'] = JobPosting::model()->findAllByAttributes(array("industry_id" => $industryProfile->industry_id));
        $data['consulting_projectss'] = JobPosting::model()->findAllByAttributes(array("industry_id" => $industryProfile->industry_id));
        $this->render('portal', array('data' => $data));
    }

    public function actionCreateintership() {
        $data = array();
        $model = new IndustryInternship;

        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);
        $industryProfile =  IndustryUser::model()->findByAttributes(array("user_id" => Yii::app()->user->id));
        if (isset($_POST['IndustryInternship'])) {
            $_POST['IndustryInternship']['industry_id'] =  $industryProfile->industry_id;
            $_POST['IndustryInternship']['start_date'] = $_POST['example10'];
            $_POST['IndustryInternship']['end_date'] = $_POST['example11'];
            $model->attributes = $_POST['IndustryInternship'];
            if ($model->save()){
                $this->redirect(array('portal','thankd'=>1));
            }else {
                foreach($model->getErrors() as $key=>$errors){
                    $this->errors[$key]  = $errors[0];
                }
            }
            
        }
        $data['modules'] = Module::model()->findAll();
        $data['cities'] = getCities();
        $this->render("createintership", array('data_renderer' => $data, 'model' => $model));
    }

    public function actionCreateproject() {
        $data = array();
        $model = new LiveProjects;

        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);
        $industryProfile =  IndustryUser::model()->findByAttributes(array("user_id" => Yii::app()->user->id));
        if (isset($_POST['LiveProjects'])) {
            $_POST['LiveProjects']['industry_id'] = $industryProfile->industry_id;
            $_POST['LiveProjects']['start_date'] = $_POST['example10'];
            $_POST['LiveProjects']['end_date'] = $_POST['example11'];
            $model->attributes = $_POST['LiveProjects'];
            if ($model->save()){
                $this->redirect(array('portal','thankd'=>1));
            }else {
                foreach($model->getErrors() as $key=>$errors){
                    $this->errors[$key]  = $errors[0];
                }
            }
            
        }
        $data['modules'] = Module::model()->findAll();
        $data['cities'] = getCities();
        $this->render("createproject", array('data_renderer' => $data, 'model' => $model));
    }
    
    
    public function actionCreatejobs() {
        $data = array();
        $model = new JobPosting;

        // Uncomment the following line if AJAX validation is needed
        // $this->performAjaxValidation($model);
        $industryProfile =  IndustryUser::model()->findByAttributes(array("user_id" => Yii::app()->user->id));
        if (isset($_POST['JobPosting'])) {
            $_POST['JobPosting']['industry_id'] = $industryProfile->industry_id;
            $model->attributes = $_POST['JobPosting'];
            if ($model->save()){
                $this->redirect(array('portal','thankd'=>1));
            }else {
                foreach($model->getErrors() as $key=>$errors){
                    $this->errors[$key]  = $errors[0];
                }
            }
            
        }
        $data['modules'] = Module::model()->findAll();
        $data['cities'] = getCities();
        $this->render("createjobs", array('data_renderer' => $data, 'model' => $model));
    }
    
    public function actionCreateconsultingprojects() {
        $data = array();
        $userData = Users::model()->findByAttributes(array("id" => Yii::app()->user->id));
        $industryProfile =  IndustryUser::model()->findByAttributes(array("user_id" => Yii::app()->user->id));
        $data['consulting_projectss'] = industryProjectWithFaculty::model()->findAllByAttributes(array("industry_id" => $industryProfile->industry_id));
        $this->render("createconsultingprojects", array('data' => $data));
    }

    

}
