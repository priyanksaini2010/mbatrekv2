<section class="banner_area">
    <div class="container">
        <h2>You are always a student, never a master. You have to keep moving forward</h2>
        <span>- Conrad Hall</span>
    </div>
</section> 
<section class="industrial_portal student_portal">

    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-4 col-xs-12 side_bar">
                <?php echo $this->renderPartial('left_menu', array("data" => $data)); ?>
            </div>
            <div class="col-md-9 col-sm-8 col-xs-12">
                <div class="right_sidebar">
                    <?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
                            'id'=>'filter-form-assigment',
                            'enableAjaxValidation'=>false,
                            'htmlOptions'=>array(
                                'class'=>'form-horizontal',


                        ))); ?>
                    <div class="function_div">
                        <select id="module-assignments" name="module">
                            <option value="">Module</option>
                            <?php foreach ( $data['modules'] as $module){ ?>
                            <option <?php if ($module->id == $data['module']) {?>selected="selected"<?php }?> value="<?php echo $module->id;?>"><?php echo $module->name;?></option>
                            <?php }?>
                        </select>
                    </div>
                    <?php $this->endWidget();?>
                    <div class="to_do_container to_do_expand">
                        <h3>To - Do List</h3>
                        <div class="session_table">
                            <div class="portal_last">
                                <table class="col-md-12 table-bordered ">
                                    <thead class="cf">
                                        <tr>
                                            <th class="first_th">S.No.</th>
                                            <th class="module_text">Module</th>
                                            <th class="module_text">Title</th>
                                            <th  class="scrose_text">Due Date</th>
                                            <th  class="scrose_text">Open</th>
                                            <th  class="scrose_text">Close</th>
                                            <th  class="scrose_text">Status</th>
                                            <th  class="scrose_text">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($data['assigments'] as $counterAssignment=>$assignment){?>
                                        <tr>
                                            <td><?php echo $counterAssignment+1;?></td>
                                            <td><p><?php echo $assignment->module->name;?></p></td>
                                            <td><p><?php echo $assignment->title;?></p></td>
                                            <td class="date_text"><p><?php echo date("d.m.Y", strtotime($assignment->due_date));?></p></td>
                                            <td class="date_text"><?php echo date("d.m.Y", strtotime($assignment->open_date));?></td>
                                            <td class="date_text"><?php echo date("d.m.Y", strtotime($assignment->close_date));?></td>
                                            <td>
                                                <?php
                                                    $attributes = array(
                                                        "student_id" => $data['student_profile']->id ,
                                                        "module_assignment_id" =>$assignment->id,
                                                    );
                                                    $studentScore = ModuleAssignmentStudentScore::model()->findByAttributes($attributes);
                                                    if (!empty($studentScore)) {
                                                        switch($studentScore->status) {
                                                            case 1:
                                                                    echo "Started";
                                                                break;
                                                            case 2:
                                                                    echo "Completed";
                                                                break;
                                                            case 3:
                                                                    echo "Closed";
                                                                break;
                                                        }
                                                    } else {
                                                        echo "Not Started";
                                                    }
                                                ?>
                                            </td>
                                            <td>
                                                <?php
                                                    $or = false;
                                                    $id = "nocheck";
                                                    if (!empty($studentScore)) {
                                                        switch($studentScore->status) {
                                                            case 1:
                                                                   $link = Yii::app()->createUrl("student/quizstart",array("id"=>$assignment->id));
                                                                   $text = "Continue";
                                                                break;
                                                            case 2:
                                                                    $route = "student/close";
                                                                    $link = Yii::app()->createUrl($route,array("id"=>$studentScore->id));
                                                                    $text = "Close Assigment";
                                                                    $id = "check-close";
                                                                    $or  = true;
                                                                break;
                                                            case 3:
                                                                    $link = "javascript::void('0');";
                                                                    $text = "No Action Required";
                                                                break;
                                                        }
                                                    } else {
                                                        $route = "student/quizstart";
                                                        $link = Yii::app()->createUrl($route,array("id"=>$assignment->id));
                                                        $text = "Start Quiz";
                                                    }
                                                ?>
                                                <a id="<?php echo $id;?>" style="color:#333333 !important;" href="<?php echo $link?>"> <?php echo $text;?></a>
                                                <?php if($or){?>
                                                <br />
                                                OR
                                                <br/>
                                                <a style="color:#333333 !important;" href="<?php echo Yii::app()->createUrl("student/quizstart",array("id"=>$assignment->id))?>"> Retake Quiz</a>
                                                <?php }?>
                                            </td>
                                        </tr>
                                        <?php }?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
