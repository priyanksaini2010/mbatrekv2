<div class="left_sidebar">
    <div class="left_heading">
        <h2>Course Schedule</h2>
    </div>
    <div class="calender_div">
        <img class="img-responsive" src="images/temprary.png"/>
    </div>
<!--    <div class="left_heading">
        <h2>Course Schedule</h2>
    </div>-->
<!--    <div class="strenth_container">
        <div class="post_content">
            <div id="content2-1" class="content">
                <ul class="list-unstyled">
                    <?php // foreach ($data['courseSchedules'] as $schedule) { ?>
                        <li><?php // echo $schedule->details; ?></li>

                    <?php // } ?>
                </ul>
            </div>
        </div>
    </div>-->
    <div class="left_heading">
        <h2>Area Of Improvements</h2>
    </div>
    <div class="imporvment_Container">
        <div class="post_content">
            <div id="content3-1" class="content">
                <ul class="list-unstyled">
                    <?php foreach ($data['areaOfImprovements'] as $schedule) { ?>
                        <li><?php echo $schedule->notes; ?></li>

                    <?php } ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="links_container">
        <ul class="list-unstyled">
            <li><a href="<?php echo Yii::app()->createUrl('student/casestudy'); ?>">Case Studies</a></li>
            <li><a href="<?php echo Yii::app()->createUrl('student/webinars'); ?>">Webinar</a></li>
            <li><a href="<?php echo Yii::app()->createUrl('student/speakertakeaway'); ?>">Speaker’s Take Away</a></li>
            <li><a href="<?php echo Yii::app()->createUrl('student/library'); ?>">Library</a></li>
        </ul>
    </div>
</div> 
