<?php
$int = InstituteBatches::model()->findByPk($_GET['institute_batch_id']);
$caseDetail = ModuleCasestudy::model()->findByPk($_GET['casestudy_id']);
$caseQuizDetail = CasestudyQuiz::model()->findByPk($_GET['casestudy_quiz_id']);
$this->breadcrumbs=array(
	$int->instituteCourse->institute->name=>array('institutes/admin'),
        $int->instituteCourse->course->name=> array('instituteCourse/admin','institute_id' => $int->instituteCourse->institute->id),
        $int->name => array('instituteBatches/view','institute_course_id' => $int->instituteCourse->course->id,'id'=>$int->id),
        $caseDetail->title => array('moduleCasestudy/view','institute_batch_id' => $int->id,'id'=>$caseDetail->id),
        "Question Id #".$caseQuizDetail->id => array('casestudyQuiz/view','institute_batch_id' => $int->id,'casestudy_id'=>$caseDetail->id,'id'=>$caseDetail->id),
	'Create Answers',
);

$this->menu=array(
        array('label'=>'Manage Answers','url'=>array('casestudyQuizAnwers/admin','institute_batch_id'=>$_GET['institute_batch_id'],'casestudy_id'=>$_GET['casestudy_id'],'casestudy_quiz_id'=>$_GET['casestudy_id'])),
	array('label'=>'Add Answers','url'=>array('casestudyQuizAnwers/create','institute_batch_id'=>$_GET['institute_batch_id'],'casestudy_id'=>$_GET['casestudy_id'],'casestudy_quiz_id'=>$_GET['casestudy_id'])),
    
);

?>
<h1>Create Answer</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>