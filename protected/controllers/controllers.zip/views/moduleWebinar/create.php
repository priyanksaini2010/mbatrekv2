<?php
if ($_GET['type'] == 1) {
    $text = "Webinars";
} else {
    $text = "Speaker's Takeaway";
}
$int = InstituteBatches::model()->findByPk($_GET['institute_batch_id']);
$this->breadcrumbs=array(
	$int->instituteCourse->institute->name=>array('institutes/admin'),
        $int->instituteCourse->course->name=> array('instituteCourse/admin','institute_id' => $int->instituteCourse->institute->id),
        $int->name => array('instituteBatches/view','institute_course_id' => $int->instituteCourse->course->id,'id'=>$int->id),
        'Create '.$text,
);


$this->menu=array(
	array('label'=>'Manage '.$text,'url'=>array('admin','institute_batch_id'=>$_GET['institute_batch_id'],'type'=>$_GET['type'])),
);


?>

<h1>Create <?php echo $text;?></h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>