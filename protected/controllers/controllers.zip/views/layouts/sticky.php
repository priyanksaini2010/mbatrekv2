<div class="sticky-container">
    <ul class="sticky">
        <li>
            <a href="https://www.facebook.com/MBAtrek-1084606068302037/" target="_blank">
                <span>Facebook</span>
                <img width="32" height="32" title="" alt="" src="images/fb1.png" /></a>
        </li>
        <li>
            <a href="https://twitter.com/MBAtrekIndia" target="_blank">
                <span>Twitter</span>
                <img width="32" height="32" title="" alt="" src="images/tw1.png" /></a>
        </li>
        <li>
            <a href="https://www.linkedin.com/company/mbatrek-prviate-ltd." target="_blank">
                <span>Linkedin</span>
                <img width="32" height="32" title="" alt="" src="images/li1.png" /></a>
        </li>
        <li>

            <span>RSS</span>
            <img width="32" height="32" title="" alt="" src="images/rss1.png" />
        </li>
        <li>
            <a href="https://plus.google.com/u/1/100170860140616487906" target="_blank">
                <span>Google+</span>
                <img width="32" height="32" title="" alt="" src="images/google_plus.png" /></a>
        </li>
        <li class="founder">
            <a href="https://www.linkedin.com/in/aloksrivastava-mbatrek" target="_blank">
                <span>Founder</span>
                <img width="32" height="32" title="" alt="" src="images/social_alok.png" /></a>
        </li>

    </ul>
</div>