<script>
$(":file").filestyle({buttonName: "btn-primary"});
</script>

<script>
    function validateEmail(emailField) {
        var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (reg.test(emailField) == false)
        {

            return false;
        }

        return true;

    }
    function getExtension(path) {
        var basename = path.split(/[\\/]/).pop(), // extract file name from full path ...
                // (supports `\\` and `/` separators)
                pos = basename.lastIndexOf(".");       // get last position of `.`

        if (basename === "" || pos < 1)            // if file name is empty or ...
            return "";                             //  `.` not found (-1) or comes first (0)

        return basename.slice(pos + 1);            // extract extension ignoring `.`
    }
    function openComingSoon() {
        $('#myModalComingSoon').modal('show');
    }
    $(document).ready(function() {


        $("#Users_program").change(function() {
            var valin = $(this).val();
            $.ajax({
                url: '<?php echo Yii::app()->createUrl('site/batch'); ?>',
                type: 'post',
                data: {
                    'institute_course_id': valin
                },
                success: function(data) {
                    $("#Users_batch").html(data);
                }
            })
        });

        $("#institute_id").change(function() {
            var valin = $(this).val();
            $.ajax({
                url: '<?php echo Yii::app()->createUrl('site/getprograms'); ?>',
                type: 'post',
                data: {
                    'institute_id': valin
                },
                success: function(data) {
                    $("#Users_program").html(data);
                }
            });
        });
        $("#example10").dateDropdowns({
            submitFieldName: 'example10',
            required: true
        });
        $("#example11").dateDropdowns({
            submitFieldName: 'example11',
            required: true
        });
        $('.menu_list').slideAndSwipe();
        $("#blog-comment").submit(function() {
            if ($("#comment").val() == "") {
                $("#comment").focus()
                $('#myModalmessage').modal('show');
                return false;
            }
            if ($("#name").val() == "") {
                $("#name").focus()
                $('#myModalname').modal('show');
                return false;
            }
            if ($("#email").val() == "" || !validateEmail($("#email").val())) {
                $("#email").focus()
                $('#myModalemail').modal('show');
                return false;
            }
        })
        $("#industry-form").submit(function() {
            if ($("#Users_email").val() == "" || !validateEmail($("#Users_email").val())) {
                $("#Users_email").focus()
                $('#myModalemail').modal('show');
                return false;
            }
            if ($("#Users_password").val() == "") {
                $("#Users_password").focus()
                $('#myModalpassword').modal('show');
                return false;
            }
            if ($("#Users_fname").val() == "") {
                $("#Users_fname").focus()
                $('#myModalfname').modal('show');
                return false;
            }
            if ($("#Users_lname").val() == "") {
                $("#Users_lname").focus()
                $('#myModallname').modal('show');
                return false;
            }
        });
        $("#mba-student-form").submit(function() {
            if ($("#Users_email").val() == "" || !validateEmail($("#Users_email").val())) {
                $("#Users_email").focus()
                $('#myModalemail').modal('show');
                return false;
            }
            if ($("#Users_password").val() == "") {
                $("#Users_password").focus()
                $('#myModalpassword').modal('show');
                return false;
            }
            if ($("#Users_fname").val() == "") {
                $("#Users_fname").focus()
                $('#myModalfname').modal('show');
                return false;
            }
            if ($("#Users_lname").val() == "") {
                $("#Users_lname").focus()
                $('#myModallname').modal('show');
                return false;
            }
        });
        $("#login-form").submit(function() {
            if ($("#LoginForm_username").val() == "" || !validateEmail($("#LoginForm_username").val())) {
                $("#LoginForm_username").focus()
                $('#myModalemail').modal('show');
                return false;
            }
            if ($("#LoginForm_password").val() == "") {
                $("#LoginForm_password").focus()
                $('#myModalpassword').modal('show');
                return false;
            }
        });
        $("#ebroucher-download-form-form").submit(function() {
            if ($("#EbroucherDownloadForm_email").val() == "" || !validateEmail($("#EbroucherDownloadForm_email").val())) {
                $("#EbroucherDownloadForm_email").focus()
                $('#myModalemail').modal('show');
                return false;
            }
            if ($("#EbroucherDownloadForm_first_name").val() == "") {
                $("#EbroucherDownloadForm_first_name").focus()
                $('#myModalfname').modal('show');
                return false;
            }
            if ($("#EbroucherDownloadForm_last_name").val() == "") {
                $("#EbroucherDownloadForm_last_name").focus()
                $('#myModallname').modal('show');
                return false;
            }
            var win = window.open('');
            window.oldOpen = window.open;
            window.open = function(url) { // reassignment function
                win.location = url;
                window.open = oldOpen;
                win.focus();
            }
            $.ajax({
                type: 'post',
                data: {
                    "EbroucherDownloadForm[email]": $("#EbroucherDownloadForm_email").val(),
                    "EbroucherDownloadForm[first_name]": $("#EbroucherDownloadForm_first_name").val(),
                    "EbroucherDownloadForm[last_name]": $("#EbroucherDownloadForm_last_name").val(),
                    "EbroucherDownloadForm[phone_number]": $("#EbroucherDownloadForm_phone_number").val()
                },
                success: function(data) {
                    var decodedData = $.parseJSON(data);
//                                alert(decodedData);
                    window.open(decodedData.url, '_blank');
                    window.location.href = "<?php echo Yii::app()->createUrl("site/index") ?>"
                }
            });
            return false;
        });
        $("#feedback-form").submit(function() {
            if ($("#Feedback_email").val() != "") {
                if (!validateEmail($("#Feedback_email").val())) {
                    $("#Feedback_email").focus()
                    $('#myModalemail').modal('show');
                    return false;
                }
            }
            if ($("#Feedback_message").val() == "") {
                $("#Feedback_message").focus()
                $('#myModalmessage').modal('show');
                return false;
            }
        });
        $("#submit_library_book").click(function() {
            if ($("#book-name").val() == "") {
                $("#book-name").focus()
                $('#myModalBookName').modal('show');
                return false;
            }
            if ($("#book-author").val() == "") {
                $("#book-author").focus()
                $('#myModalAuthor').modal('show');
                return false;
            }
            if ($("#book-subject").val() == "") {
                $("#book-subject").focus()
                $('#myModalSubjectBook').modal('show');
                return false;
            }
            if ($("#books-file").val() == "") {
                $("#books-file").focus()
                $('#myModalBookFile').modal('show');
                return false;
            }
            // get the file name, possibly with path (depends on browser)
            var filename = $("#books-file").val();

            // Use a regular expression to trim everything before final dot
            var extension = filename.replace(/^.*\./, '');

            // Iff there is no dot anywhere in filename, we would have extension == filename,
            // so we account for this possibility now
            if (extension == filename) {
                extension = '';
            } else {
                // if there is an extension, we convert to lower case
                // (N.B. this conversion will not effect the value of the extension
                // on the file upload.)
                extension = extension.toLowerCase();
            }
//            if (extension != "pdf" && ) {
//                $("#books-file").focus()
//                $('#myModalBookFile').modal('show');
//                return false;
//            }
            $("#filter-form-library").submit();

        });
        $("#filter-batch").change(function() {
            $("#filter-form-attendance").submit();
        })
        $("#filter-module").change(function() {
            $("#filter-form-attendance").submit();
        })
        $("#filter-batch-score").change(function() {
            $("#filter-form-score").submit();
        })
        $("#filter-module-score").change(function() {
            $("#filter-form-score").submit();
        })
        $("#filter-module-interationlanding").change(function() {
            $("#filter-form-interationlanding").submit();
        })
        $("#id-past").change(function() {
            $("#filter-form-interationlanding-pas").submit();
        })
        $("#functions-casestudy").change(function() {
            $("#filter-form-casestudy").submit();
        })
        $("#module-assignments").change(function() {
            $("#filter-form-assigment").submit();
        })

        $("#submit-quiz-case").click(function() {
            var jsonObj = [];
            $(".quize_question_all").each(function(i, obj) {
                if ($(this).is(":checked")) {
                    var quizid = $(this).attr('src');
                    var answer = $(this).attr('value');
                    var item = {}
                    item ["question_id"] = quizid;
                    item ["answer_id"] = answer;
                    jsonObj.push(item);
                }
            });
            var casestudy_id = $("#casestudy_id").val();
            $.ajax({
                url: '<?php echo Yii::app()->createUrl('student/checkCaseStudyAnswer'); ?>',
                type: 'post',
                data: {
                    'answers': jsonObj,
                    'casestudy_id': casestudy_id
                },
                success: function(data) {
                    var decodedData = $.parseJSON(data);
                    if (decodedData.status == "success") {
                        $("#total_answered").html(decodedData.data.question_answered);
                        $("#total_correct").html(decodedData.data.correct);
                        $("#score").html(decodedData.data.student_score);
                        $("#total_score").html(decodedData.data.total_score);
                        $("#myModal1").modal('show');
                    } else {
                        $("#message_errors").html(decodedData.msg);
                        $("#myModalQuizError").modal('show');
                    }

                }
            })


        })
        $("#check-close").click(function() {
            if (!confirm("Are you sure you want to close this assigment? No further changes will be allowed.")) {
                return false;
            }
        });
        $("#submit-quiz-assigment").click(function() {
            var jsonObj = [];
            $(".quize_question_all").each(function(i, obj) {
                if ($(this).is(":checked")) {
                    var quizid = $(this).attr('src');
                    var answer = $(this).attr('value');
                    var item = {}
                    item ["question_id"] = quizid;
                    item ["answer_id"] = answer;
                    jsonObj.push(item);
                }
            });
            var assigment_id = $("#assigment_id").val();
            $.ajax({
                url: '<?php echo Yii::app()->createUrl('student/checkAssigmentAnswer'); ?>',
                type: 'post',
                data: {
                    'answers': jsonObj,
                    'assigment_id': assigment_id
                },
                success: function(data) {
                    var decodedData = $.parseJSON(data);
                    if (decodedData.status == "success") {
                        $("#total_answered").html(decodedData.data.question_answered);
                        $("#total_correct").html(decodedData.data.correct);
                        $("#score").html(decodedData.data.student_score);
                        $("#total_score").html(decodedData.data.total_score);
                        $("#myModal1").modal('show');
                    } else {
                        $("#message_errors").html(decodedData.msg);
                        $("#myModalQuizError").modal('show');
                    }

                }
            })


        })
        $("#contact-form").submit(function() {
            if ($("#Contact_email").val() == "" || !validateEmail($("#Contact_email").val())) {
                $("#Contact_email").focus()
                $('#myModalemail').modal('show');
                return false;
            }
            if ($("#Contact_name").val() == "") {
                $("#Contact_name").focus()
                $('#myModalname').modal('show');
                return false;
            }
            if ($("#Contact_phone").val() == "") {
                $("#Contact_phone").focus()
                $('#myModalPhone').modal('show');
                return false;
            }
            if ($("#Contact_subject").val() == "") {
                $("#Contact_subject").focus()
                $('#myModalSubject').modal('show');
                return false;
            }
            if ($("#Contact_message").val() == "") {
                $("#Contact_message").focus()
                $('#myModalTxtMsg').modal('show');
                return false;
            }
        });
        $("#submit_library_profile").click(function() {
            $("#filter-form-profile").submit();
        })
<?php if (isset($_REQUEST['thank']) && $_REQUEST['thank'] == 1) { ?>

            $("#myModalthank").modal('show');

<?php } ?>
<?php if (isset($_REQUEST['thankBook']) && $_REQUEST['thankBook'] == 1) { ?>

            $("#myModalthankBook").modal('show');

<?php } ?>
<?php if (isset($_REQUEST['thankc']) && $_REQUEST['thankc'] == 1) { ?>

            $("#myModalthankc").modal('show');

<?php } ?>
<?php if (isset($_REQUEST['thankd']) && $_REQUEST['thankd'] == 1) { ?>

            $("#myModalthankd").modal('show');

<?php } ?>
<?php if (isset($this->errors) && count($this->errors) > 0) { ?>

            $("#myModalclient").modal('show');

<?php } ?>
<?php if (isset($this->success) && count($this->success) > 0) { ?>
            $("#myModalSuccess").modal('show');
            window.setTimeout(function() {
                location.href = "<?php echo Yii::app()->createUrl('site/index'); ?>";
            }, 2500);
<?php } ?>

    });

</script>
<script type="text/javascript">


</script>
<script>
    $('#add_more_link').click(function() {
        $('.industry_field:last').after('<div class="col-md-12 col-sm-12 col-xs-12"><div class="phAnimate"><input type="text" placeholder="industry" name="profile_industry[]" class="input_field" id="Email"><a class="add_more_link remove_link" href="javascript:void(0);">Remove</a></div></div>');
    });

    $('#company_more').click(function() {
        $('.company_filed:last').after('<div class="col-md-12 col-sm-12 col-xs-12"><div class="phAnimate"><input type="text" placeholder="Companies" name="profile_companies[]" class="input_field" id="Email"><a class="add_more_link remove_link" href="javascript:void(0);">Remove</a></div></div>');
    });

    $('#internship_link').click(function() {
        $('.internship_filed:last').after('<div class="col-md-12 col-sm-12 col-xs-12"><div class="phAnimate"><input type="text" placeholder="Internship" name="profile_intership[]" class="input_field" id="Email"><a class="add_more_link remove_link" href="javascript:void(0);">Remove</a></div></div>');
    });

    $('#live_linkd').click(function() {
        $('.live_project:last').after('<div class="col-md-12 col-sm-12 col-xs-12"><div class="phAnimate"><input type="text" placeholder="Live Project" name="profile_liveproject[]" class="input_field" id="Email"><a class="add_more_link remove_link" href="javascript:void(0);">Remove</a></div></div>');
    });

    $('.edit_profile_form').on('click', '.remove_link', function() {
//	alert('hi');
        $(this).parent().remove();
    });

</script>