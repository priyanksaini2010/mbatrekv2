<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
    <head>
        <title><?php echo Yii::app()->name . " ";
echo isset($this->pageTitle) ? ": " . $this->pageTitle : "";
?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="description" content="" />
        <meta name="keywords" content="" />
        <meta name="robots" content="index,follow" />
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
        <script src="js/jquery.DEPreLoad.js"></script>
        <script src="js/modernizr.custom.js"></script>
        <link rel="stylesheet" type="text/css" href="css/styles.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
        <!--[if lt IE 8]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
        <!-----------Preloader JS-------------------->
        <script>
            $(document).ready(function() {

                setTimeout(function() {
                    $("#depreload .wrapper").animate({opacity: 1});
                }, 400);

                setTimeout(function() {
                    $("#depreload .logo").animate({opacity: 1});
                }, 800);

                var canvas = $("#depreload .line")[0],
                        context = canvas.getContext("2d");

                context.beginPath();
                context.arc(88, 103, 83, Math.PI * 1.5, Math.PI * 1.6);
                context.strokeStyle = '#DABC22';
                context.lineWidth = 5;
                context.stroke();

                var loader = $("body").DEPreLoad({
                    OnStep: function(percent) {
                        console.log(percent + '%');

                        $("#depreload .line").animate({opacity: 1});
                        $("#depreload .perc").text(percent + "%");

                        if (percent > 5) {
                            context.clearRect(0, 0, canvas.width, canvas.height);
                            context.beginPath();
                            context.arc(88, 103, 83, Math.PI * 1.5, Math.PI * (1.5 + percent / 50), false);
                            context.stroke();
                        }
                    },
                    OnComplete: function() {
                        console.log('Everything loaded!');

                        $("body").addClass('remove_overflow');
						$("#depreload").addClass('loaded_dom');
                        // $("#depreload .perc").text("done");
                        $("#depreload .loading").animate({opacity: 0});
                    }
                });
            });
        </script>
        <!-----------End Preloader JS-------------------->
    </head>
    <?php
    $controller = $this->uniqueid;
    $action = $this->action->Id;
    $view = isset($_REQUEST['view']) ? $_REQUEST['view'] : "";
    $dataSite = ContentJson::model()->findByAttributes(array('page' => 'home'));
    $dataSite = json_decode($dataSite->data);
    if (isset(Yii::app()->user->id)) {
        $userData = Users::model()->findByPk(Yii::app()->user->id);
        switch ($userData->role) {
            case 1:
                $route = 'student/portal';
                break;
            case 2:
                $route = 'industry/portal';
                break;
            case 3:
                $route = 'institutes/portal';
                break;
            default :
                $route = "";
                break;
        }
    } else {
        $route = "";
    }
    ?>
    <body>
<?php if ( $route == 'student/portal' && $controller == "student") { 
    $studentData  = Students::model()->findByAttributes(array('user_id' => Yii::app()->user->id)); ;
    $userData  = Users::model()->findByPk( Yii::app()->user->id);
    $json = isset($studentData->profile_json) && !empty($studentData->profile_json)?json_decode($studentData->profile_json):"";
?>
            <div class="student_info_fx">
                <a class="student_profile" href="javascript:void(0);">Student Profile</a>
                <div class="profile_coantainer">
                    <div class="profile_student">
                        <img src="<?php echo isset($json->profile_pic)?"assets/resumes/".$json->profile_pic:"images/defualt_user.jpg"?>"/>
                        <ul class="list-unstyled list-inline">
                            <li><a target="__blank" href="<?php echo isset($json->profile_fb)?$json->profile_fb:"javascript:void(0);"?>"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li><a target="__blank" href="<?php echo isset($json->profile_linked)?$json->profile_linked:"javascript:void(0);"?>"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
                        </ul>
                    </div>
                    <div class="profile_content">
                        <h3><a href="<?php echo Yii::app()->createUrl("student/editprofile");?>"><?php echo Yii::app()->user->name;?><a/></h3>
                        <p>ID: <?php echo $userData->id;?></p>
                        <p>Last Logged in: <?php echo date("d.m.Y",  strtotime($userData->last_login));?></p>
                        <p>Attendance: 80%</p>
                    </div>
                    <div class="resume_studetn">
                        <div class="site_btn"><a class="raised ripple has-ripple" href="<?php echo Yii::app()->createUrl("student/editprofile");?>">Resume </a></div>
                    </div>
                    <h3 class="fcus_hding">Focus Area</h3>
                    <div id="content1-1" class="content">
                        <div class="focus_area">
                            
                            <h2><a href="<?php echo Yii::app()->createUrl("student/editprofile",array("display"=>"ind"));?>">1) Industry</a></h2>
                            <ul class="list-unstyled">
                                <?php if(isset($json->profile_industry) && !empty($json->profile_industry)){?>
                                <?php foreach ($json->profile_industry as $ind){?>
                                    <li><?php echo $ind;?></li>
                                <?php }}?>
                                
                            </ul>
                        </div>
                        <div class="focus_area">
                            <h2><a href="<?php echo Yii::app()->createUrl("student/editprofile",array("display"=>"comp"));?>">2) Companies</a></h2>
                            <ul class="list-unstyled">
                                <?php if(isset($json->profile_companies) && !empty($json->profile_companies)){?>
                                <?php foreach ($json->profile_companies as $ind){?>
                                    <li><?php echo $ind;?></li>
                                <?php }}?>
                            </ul>
                        </div>
                        <div class="focus_area">
                            <h2><a href="<?php echo Yii::app()->createUrl("student/editprofile",array("display"=>"int"));?>">3) Internship</a></h2>
                            <ul class="list-unstyled">
                                <?php if(isset($json->profile_intership) && !empty($json->profile_intership)){?>
                                <?php foreach ($json->profile_intership as $ind){?>
                                    <li><?php echo $ind;?></li>
                                <?php }}?>
                            </ul>
                        </div>
                        <div class="focus_area">
                            <h2><a href="<?php echo Yii::app()->createUrl("student/editprofile",array("display"=>"live"));?>">4) Live Project</a></h2>
                            <ul class="list-unstyled">
                                <?php if(isset($json->profile_liveproject) && !empty($json->profile_liveproject)){?>
                                <?php foreach ($json->profile_liveproject as $ind){?>
                                    <li><?php echo $ind;?></li>
                                <?php }}?>
                            </ul>
                        </div>
                        
                    </div>
                </div>
            </div>
<?php } ?>
        <div id="depreload" style="background-image:url('../images/bgr.jpg');" class="table">
            <div class="table-cell wrapper">
                <div class="circle">
                    <canvas class="line" width="178px" height="189px"></canvas>
                    <img src="images/preloader.png" class="logo" alt="logo" />
                </div>
                <p class="perc"></p>
                <p class="loading">MBAtrek Loading...</p>
            </div> 
        </div> 
        <div class="full_wrapper ">
            <?php echo $this->renderPartial("/layouts/sticky");?>

            <header>
                <?php echo $this->renderPartial("/layouts/mobilemenu");?>
                <?php echo $this->renderPartial("/layouts/mainmenu");?>
            </header>
            <article>
<?php echo $content; ?>
            </article>
            <footer class="footer_container">
                <?php echo $this->renderPartial("/layouts/footer");?>
                <?php echo $this->renderPartial("/layouts/popups");?>
                <?php echo $this->renderPartial("/layouts/popupsindustry");?>
                <div id="myModalclient" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content row">
                            <div class="modal-body">
                                <div class="md-content">
                                    <h3>Error</h3>
                                    <div class="error_wrap">
<?php
if (isset($this->errors) && count($this->errors) > 0) {

    foreach ($this->errors as $key => $error) {
        ?>
                                                <div class="error_container">
                                                    <p><i class="fa fa-warning" aria-hidden"true"=""></i> <?php echo $error; ?></p>
                                                </div>
    <?php }
}
?>
                                        <!-- <button class="md-close">OK</button> -->
                                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </footer> 
        </div>
        <script src="js/bootstrap.js"></script>
	<script src="js/custom.js"></script>
	<script src="js/jquery.materialripple.js"></script>
	<script src="js/classie.js"></script>
	<script src="js/jquery.goup.js"></script>
	<script src="js/jquery.slideandswipe.js"></script>
	<script src="js/jquery.mCustomScrollbar.js"></script>
	<script src="js/canvasjs.min.js"></script>
	<script src="js/bootstrap-datepicker.js"></script>
	<script src="js/jquery.touchSwipe.min.js"></script>
	<script src="js/jquery.viewbox.js"></script>
	<script src="js/velocity.min.js"></script>
	<script src="js/velocity.ui.min.js"></script>
	<script src="js/jquery.date-dropdowns.js"></script>
	<script src="js/bootstrap-filestyle.js"></script>
        <?php echo $this->renderPartial("/layouts/graphscript");?>
        
        <?php echo $this->renderPartial("/layouts/scripts");?>
        <?php echo $this->renderPartial("/layouts/scriptsindustry");?>
    </body>
</html>
    