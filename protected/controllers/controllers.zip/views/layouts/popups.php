<div id="myModalemail" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter valid email address!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalpassword" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter password!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalfname" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter first name!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalComingSoon" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3></h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i>Coming Soon</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalPhone" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter Phone number!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalname" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter name!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModallname" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter last name!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalmessage" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter a valid message.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalthank" class="modal success" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Thanks</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Thanks for your feedback</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalthankBook" class="modal success" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Thanks</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Thanks for your feedback.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalthankc" class="modal success" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Thanks</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> We have received your query. Will get in touch soon.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalthankd" class="modal success" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Thanks</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i>Thank You, Your requirement is submitted.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalSubject" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i>  Please enter a valid subject.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalTxtMsg" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i>  Please enter a message.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalCity" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i>  Please select a valid city.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalNoImage" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Sorry no brochure available.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalQuizError" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p id="message_errors">Sorry no brochure available.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalBookName" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p id="message_errors"><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter a valid book name.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalAuthor" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p id="message_errors"><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter a valid author name.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalSubjectBook" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p id="message_errors"><i class="fa fa-warning" aria-hidden"true"=""></i> Please select a subject.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalBookFile" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p id="message_errors"><i class="fa fa-warning" aria-hidden"true"=""></i> Please upload a pdf file..</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalSuccess" class="modal success" data-easein="pulse" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Success</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> You have been successfully registered, Please check you email.</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>