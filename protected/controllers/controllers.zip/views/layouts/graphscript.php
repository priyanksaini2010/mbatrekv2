<?php


    $usersAll = Users::model()->findAllByAttributes(array("role"=>1));
    $cities = array();
    foreach ($usersAll as $us) {
        if ($us->city == "") {
            $us->city = "Others";    
        }
        if (!array_key_exists($us->city, $cities)) {
            
            $cities[$us->city] = 0;
        }
        
    }
    foreach ($usersAll as $uss) {
        $cities[$uss->city] = $cities[$uss->city]+1;
    }
    $optcit = array();
    foreach ($cities as $ks => $ds) {
        
            $optcit[] = array("name" => $ks, "y" => $ds, "exploded" =>"true");
    }
//    pr($optcit);
    $controller = $this->uniqueid;
    $action = $this->action->Id;
    $view = isset($_REQUEST['view']) ? $_REQUEST['view'] : "";?>
<script type="text/javascript">
    window.onload = function() {
<?php
if (($controller == "institutes" && $action == "portal")) {
    $data['institute'] = InstituteUser::model()->findByAttributes(array("user_id" => Yii::app()->user->id));
    foreach ($data['institute']->institute->instituteCourses[0]->instituteBatches as $keyBatch => $batch) {
        $dataMontl = PresentMonthly::model()->findAllByAttributes(array("institute_batch_id" => $batch->id));
        $datPer = array();
        $datPer2 = array();
        foreach ($dataMontl as $dataM) {
            $datPer[$dataM->date] = $dataM->total_present;
        }
        $dataAll = AllMonthly::model()->findAllByAttributes(array("institute_batch_id" => $batch->id));
        foreach ($dataAll as $dataM) {
            $datPer2[$dataM->date] = $dataM->total_students;
        }
        foreach ($datPer as $kq => $dataM) {
            $datPer[$kq] = $dataM / $datPer2[$kq] * 100;
        }
        $opts = array();
        foreach ($datPer as $k => $d) {
            $opts[] = array("label" => $k, "y" => $d);
        }
        $modules = CHtml::listData(Module::model()->findAll(), "id", "name");
        
        $modScore = array();
        foreach ($modules as $kmo=>$mo){
            $modScore[$mo] = 0;
            $totalScoreModular = 0;
            $studentScoreModular = 0;
            foreach ($batch->moduleAssignments as $assignmentKey => $assignment) {
                if ($kmo == $assignment->module_id) {
                    foreach ($assignment->moduleAssignmentStudentScores as $scoreKey => $score) {
                        $totalScoreModular = $totalScoreModular + $score->total_score;
                        $studentScoreModular = $studentScoreModular + $score->student_score;
                    }
                }
                
            }
            if ($totalScoreModular != 0) {
                $modScore[$mo] = $studentScoreModular / $totalScoreModular *100;
            } else {
                $modScore[$mo] = 0;
            }
            
        }
       
        $optscore = array();
        foreach ($modScore as $ks => $ds) {
            $optscore[] = array("label" => $ks, "y" => $ds);
        }
//         pr($optscore);
        ?>
                new CanvasJS.Chart("chartContainer" +<?php echo $batch->id ?>,
                        {
                            title: {
                                //text: "Gaming Consoles Sold in 2012"
                            },
                            animationEnabled: true,
                            legend: {
                                verticalAlign: "bottom",
                                horizontalAlign: "center"
                            },
                            data: [
                                {
                                    indexLabelFontSize: 13,
                                    //indexLabelFontFamily: "arial",       
                                    indexLabelFontColor: "white",
                                    indexLabelLineColor: "darkgrey",
                                    indexLabelPlacement: "inside",
                                    type: "column",
                                    showInLegend: false,
                                    toolTipContent: "{y}%</strong>",
                                    dataPoints: <?php echo json_encode($opts); ?>
                                }
                            ]
                        }).render();
               
                new CanvasJS.Chart("chartContaineruniv" +<?php echo $batch->id ?>,
                        {
                            title: {
                                //text: "Gaming Consoles Sold in 2012"
                            },
                            animationEnabled: true,
                            legend: {
                                verticalAlign: "bottom",
                                horizontalAlign: "center"
                            },
                            data: [
                                {
                                    indexLabelFontSize: 13,
                                    //indexLabelFontFamily: "arial",       
                                    indexLabelFontColor: "white",
                                    indexLabelLineColor: "darkgrey",
                                    indexLabelPlacement: "inside",
                                    type: "column",
                                    showInLegend: false,
                                    toolTipContent: "{y}%</strong>",
                                    dataPoints: <?php echo json_encode($opts); ?>
                                }
                            ]
                        }).render();
                
                new CanvasJS.Chart("chartContainerscore" +<?php echo $batch->id ?>,
                        {
                            title: {
                                //text: "Gaming Consoles Sold in 2012"
                            },
                            animationEnabled: true,
                            legend: {
                                verticalAlign: "bottom",
                                horizontalAlign: "center"
                            },
                            data: [
                                {
                                    indexLabelFontSize: 13,
                                    //indexLabelFontFamily: "arial",       
                                    indexLabelFontColor: "white",
                                    indexLabelLineColor: "darkgrey",
                                    indexLabelPlacement: "inside",
                                    type: "column",
                                    showInLegend: false,
                                    toolTipContent: "{y}%</strong>",
                                    dataPoints: <?php echo json_encode($optscore); ?>
                                }
                            ]
                        }).render();
                 new CanvasJS.Chart("chartContainerunivscore" +<?php echo $batch->id ?>,
                        {
                            title: {
                                //text: "Gaming Consoles Sold in 2012"
                            },
                            animationEnabled: true,
                            legend: {
                                verticalAlign: "bottom",
                                horizontalAlign: "center"
                            },
                            data: [
                                {
                                    indexLabelFontSize: 13,
                                    //indexLabelFontFamily: "arial",       
                                    indexLabelFontColor: "white",
                                    indexLabelLineColor: "darkgrey",
                                    indexLabelPlacement: "inside",
                                    type: "column",
                                    showInLegend: false,
                                    toolTipContent: "{y}%</strong>",
                                    dataPoints: <?php echo json_encode($optscore); ?>
                                }
                            ]
                        }).render();
                        
                
    <?php }
    ?>
<?php } ?>
<?php 
if (($controller == "institutes" && $action == "attendance")) {
$data['institute'] = InstituteUser::model()->findByAttributes(array("user_id" => Yii::app()->user->id));
    foreach ($data['institute']->institute->instituteCourses[0]->instituteBatches as $keyBatch => $batch) {
        $dataMontl = PresentMonthly::model()->findAllByAttributes(array("institute_batch_id" => $batch->id));
        $datPer = array();
        $datPer2 = array();
        foreach ($dataMontl as $dataM) {
            $datPer[$dataM->date] = $dataM->total_present;
        }
        $dataAll = AllMonthly::model()->findAllByAttributes(array("institute_batch_id" => $batch->id));
        foreach ($dataAll as $dataM) {
            $datPer2[$dataM->date] = $dataM->total_students;
        }
        foreach ($datPer as $kq => $dataM) {
            $datPer[$kq] = $dataM / $datPer2[$kq] * 100;
        }
        $opts = array();
        foreach ($datPer as $k => $d) {
            $opts[] = array("label" => $k, "y" => $d);
        }
        $modules = CHtml::listData(Module::model()->findAll(), "id", "name");
        
        $modScore = array();
        foreach ($modules as $kmo=>$mo){
            $modScore[$mo] = 0;
            $totalScoreModular = 0;
            $studentScoreModular = 0;
            foreach ($batch->moduleAssignments as $assignmentKey => $assignment) {
                if ($kmo == $assignment->module_id) {
                    foreach ($assignment->moduleAssignmentStudentScores as $scoreKey => $score) {
                        $totalScoreModular = $totalScoreModular + $score->total_score;
                        $studentScoreModular = $studentScoreModular + $score->student_score;
                    }
                }
                
            }
            if ($totalScoreModular != 0) {
                $modScore[$mo] = $studentScoreModular / $totalScoreModular *100;
            } else {
                $modScore[$mo] = 0;
            }
            
        }
       
        $optscore = array();
        foreach ($modScore as $ks => $ds) {
            $optscore[] = array("label" => $ks, "y" => $ds);
        }?>
                new CanvasJS.Chart("avgattendance1",
                        {
                            title: {
                                //text: "Gaming Consoles Sold in 2012"
                            },
                            animationEnabled: true,
                            legend: {
                                verticalAlign: "bottom",
                                horizontalAlign: "center"
                            },
                            data: [
                                {
                                    indexLabelFontSize: 13,
                                    //indexLabelFontFamily: "arial",       
                                    indexLabelFontColor: "white",
                                    indexLabelLineColor: "darkgrey",
                                    indexLabelPlacement: "inside",
                                    type: "column",
                                    showInLegend: false,
                                    toolTipContent: "{y}%</strong>",
                                    dataPoints: <?php echo json_encode($opts); ?>
                                }
                            ]
                        }).render();
                <?php break;}
    ?>
<?php } ?>
        
        new CanvasJS.Chart("chartContainer",
		{
			title:{
				//text: "Gaming Consoles Sold in 2012"
			},
					animationEnabled: true,
			legend:{
				verticalAlign: "bottom",
				horizontalAlign: "center"
			},
			data: [
			{        
				indexLabelFontSize: 13,
				//indexLabelFontFamily: "arial",       
				indexLabelFontColor: "white", 
				indexLabelLineColor: "darkgrey",        
				indexLabelPlacement: "inside",
				type: "pie",       
				showInLegend: false,
				toolTipContent: "{name}: {y}",
				dataPoints: <?php echo json_encode($optcit);?>
			}
			]
		}).render();
		
    }
</script>

