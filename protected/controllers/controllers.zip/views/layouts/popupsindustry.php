<div id="myModalLiveProjects_company_name" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter company name!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalLiveProjects_campus" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter campus name!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalIndustryInternship_location" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please select valid city.!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalLiveProjects_function" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter functions.!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalLiveProjects_number_of_students" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter valid number of students.!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalLiveProjects_project_deliverables" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter project deliverables.!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalLiveProjects_stipend" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter valid stiped.!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalJobPosting_salary" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter valid salary.!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalIndustryInternship_number_of_openings" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter valid number of openings!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalIndustryInternship_description_of_project" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter project description.!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalJobPosting_description_of_job" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter job description.!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalJobPosting_preferred_qualification" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter prefered qualification .!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div id="myModalJobPosting_position" class="modal" data-easein="shake" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content row">
            <div class="modal-body">
                <div class="md-content">
                    <h3>Error !</h3>
                    <div class="error_wrap">
                        <div class="error_container">
                            <p><i class="fa fa-warning" aria-hidden"true"=""></i> Please enter Job  position.!</p>
                        </div>
                        <!-- <button class="md-close">OK</button> -->
                        <div class="main_register"><div class="site_btn"><a  data-dismiss="modal"class="raised ripple close" href="javascript:void(0);">OK</a></div></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>