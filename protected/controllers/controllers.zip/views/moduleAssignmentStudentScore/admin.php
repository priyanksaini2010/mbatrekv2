<?php
$int = InstituteBatches::model()->findByPk($_GET['institute_batch_id']);
$student = Students::model()->findByPk($_GET['student_id']);
$this->breadcrumbs=array(
	$int->instituteCourse->institute->name=>array('institutes/admin'),
        $int->instituteCourse->course->name=> array('instituteCourse/admin','institute_id' => $int->instituteCourse->institute->id),
        $int->name => array('instituteBatches/view','institute_course_id' => $int->instituteCourse->course->id,'id'=>$int->id),
        "Manage Students" => array('students/admin','institute_batch_id' => $int->id),
        $student->name => array('students/viewprofile','institute_batch_id' => $int->id,'id'=>$student->id),
	'Case Study Score',
);
$this->menu = array(
    array('label' =>  $student->name.' Profile', 'url' => array('students/viewprofile','institute_batch_id' => $int->id,'id'=>$student->id)),
    array('label' => 'Manage Areas of improvement', 'url' => array('studentAreaOfImprovement/admin', 'institute_batch_id' => $_GET['institute_batch_id'],'student_id'=>$_GET['student_id'])),
    array('label' => 'Case Study Score', 'url' => array('casestudyStudentScore/admin', 'institute_batch_id' => $_GET['institute_batch_id'],'student_id'=>$_GET['student_id'])),
    array('label' => 'Assignment Scores', 'url' => array('moduleAssignmentStudentScore/admin', 'institute_batch_id' => $_GET['institute_batch_id'],'student_id'=>$_GET['student_id'])),
);
?>

<h1>Assignments Scores</h1>


<?php 
$status = array(1=>'Started',2=>'Completed',3=>'Closed');
$filter = CHtml::listData(ModuleAssignment::model()->findAllByAttributes(array("institute_batch_id"=>$int->id)), "id", "title");
$this->widget('bootstrap.widgets.TbGridView',array(
	'id'=>'module-assignment-student-score-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
//		'id',
//		'module_assignment_id',
                array(
                    "filter" =>$filter,
                    "name" => 'module_assignment_id',
                    "value" => '$data->moduleAssignment->title'
                ),
//		'student_id',
		'total_score',
		'student_score',
		
            array(
                'name'=>'status',
                'filter'=>$status,
                'value'=>array($this,'getStatus')
                ),
		/*
		'close_date',
		*/
	),
)); ?>
