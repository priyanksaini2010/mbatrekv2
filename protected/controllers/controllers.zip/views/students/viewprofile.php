<?php
$int = InstituteBatches::model()->findByPk($_GET['institute_batch_id']);

$this->breadcrumbs = array(
    $int->instituteCourse->institute->name => array('institutes/admin'),
    $int->instituteCourse->course->name => array('instituteCourse/admin', 'institute_id' => $int->instituteCourse->institute->id),
    $int->name => array('instituteBatches/view', 'institute_course_id' => $int->instituteCourse->course->id, 'id' => $int->id),
    "Manage Students" => array('admin', 'institute_batch_id' => $_GET['institute_batch_id']),
    'Student Profile',
);

$this->menu = array(
    array('label' =>  $model->name.' Profile', 'url' => array('students/viewprofile','institute_batch_id' => $int->id,'id'=>$model->id)),
    array('label' => 'Manage Areas of improvement', 'url' => array('studentAreaOfImprovement/admin', 'institute_batch_id' => $_GET['institute_batch_id'],'student_id'=>$model->id)),
    array('label' => 'Case Study Score', 'url' => array('casestudyStudentScore/admin', 'institute_batch_id' => $_GET['institute_batch_id'],'student_id'=>$model->id)),
    array('label' => 'Assignment Scores', 'url' => array('moduleAssignmentStudentScore/admin', 'institute_batch_id' => $_GET['institute_batch_id'],'student_id'=>$model->id)),
);
?>

<h1><?php echo ucfirst($model->name); ?> Profile</h1>
<?php
$json = json_decode($model->profile_json);
?>
<div class="row show-grid">
    <div class="span4">
        <?php if(isset($json->profile_pic)) {?>
        <img src="assets/resumes/<?php echo $json->profile_pic;?>" height="100px" width="100px"/>
        <?php } ?>
    </div>
</div>

<p>
    <b>Name</b> : <?php echo $model->name; ?>

</p>
<p>
    <b>DOB</b> : <?php echo $model->dob; ?>
</p>
<p>
    <b>Email</b> : <a href="mailto:<?php echo $model->email; ?>"><?php echo $model->email; ?></a>

</p>
<p>
    <b> Phone Number</b> : <?php echo $model->phone_number; ?>
</p>
<p>
    <b>City</b> : <?php echo $model->city; ?>
</p>
<p>
    <b>Program</b> : <?php echo $model->program; ?>
</p>
<p>
    <b>Last Login</b> : <?php echo $model->last_login; ?>
</p>

<?php if (isset($json->profile_fb)) { ?>
    <p> 
        <b>Facebook Profile</b> : <a href="<?php echo $json->profile_fb ?>" target="__blank"/><?php echo $json->profile_fb ?></a>
    </p>
<?php } ?>
<?php if (isset($json->profile_linked)) { ?>
    <p> 
        <b> Linkedin Profile</b> : <a href="<?php echo $json->profile_linked ?>" target="__blank"/><?php echo $json->profile_linked ?></a>
    </p>
<?php } ?>
<?php if (isset($json->profile_industry)) { ?>
    <p> 
        <b>Industry</b> : <br />
    <ol>
    <?php foreach ($json->profile_industry as $ind) { ?>
            <li><?php echo $ind ?></li>
        <?php } ?>
    </ol>
    </p>
    <?php } ?>
<?php if (isset($json->profile_companies)) { ?>
    <p> 
        <b>Companies</b> : <br />
    <ol>
    <?php foreach ($json->profile_companies as $ind) { ?>
            <li><?php echo $ind ?></li>
        <?php } ?>
    </ol>
    </p>
    <?php } ?>
<?php if (isset($json->profile_intership)) { ?>
    <p> 
        <b>Internship</b> : <br />
    <ol>
    <?php foreach ($json->profile_intership as $ind) { ?>
            <li><?php echo $ind ?></li>
        <?php } ?>
    </ol>
    </p>
    <?php } ?>
<?php if (isset($json->profile_liveproject)) { ?>
    <p> 
        <b>Live Projects</b> : <br />
    <ol>
    <?php foreach ($json->profile_liveproject as $ind) { ?>
            <li><?php echo $ind ?></li>
        <?php } ?>
    </ol>
    </p>
    <?php } ?>

