<section class="banner_area institute_portal">
    <div class="container">
        <h2>You are always a student, never a master. You have to keep moving forward</h2>
        <span>- Conrad Hall</span>
    </div>
</section>  
<section class="industrial_portal student_portal">

    <div class="container">
        <div class="row">
            <?php echo $this->renderPartial("left_menu",array('data'=>$data));?>
            <div class="col-md-9 col-sm-8 col-xs-12">
                <div class="right_sidebar institute_ptl_tb">
                    <div class="module_container">
                        <div class="session_table">
                            <table class="col-md-12 table-bordered ">
                                <thead class="cf">
                                    <tr>
                                        <th class="first_th">S.No.</th>
                                        <th class="module_text">Performance</th>
                                        <th class="scrose_text">B - School</th>
                                        <th class="scrose_text">All B - School</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>
                                            <span class="attendance_span">Attendance</span>
                                            <ul class="attence_ul">
                                                <?php foreach ($data['institute']->institute->instituteCourses[0]->instituteBatches as $key => $course) { ?>
                                                    <li> <?php echo $course->name; ?></li>
                                                <?php } ?>
                                            </ul>
                                        </td>
                                        <td>
                                            <?php foreach ($data['institute']->institute->instituteCourses[0]->instituteBatches as $keyBatch => $batch) { ?>
                                                
                                            <div class="bar_graph" id="chartContainer<?php echo $batch->id;?>" style="height: 200px; width: 100%;"></div>
                                            
                                            
                                                
                                            <?php } ?>
                                        </td>
                                        <td>
                                           <?php foreach ($data['institute']->institute->instituteCourses[0]->instituteBatches as $keyBatch => $batch) { ?>
                                                
                                            <div class="bar_graph" id="chartContaineruniv<?php echo $batch->id;?>" style="height: 200px; width: 100%;"></div>
                                            
                                            
                                                
                                            <?php } ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>
                                            <span class="attendance_span">Scores</span>
                                            <ul class="attence_ul">
                                                <?php foreach ($data['institute']->institute->instituteCourses[0]->instituteBatches as $key => $course) { ?>
                                                    <li> <?php echo $course->name; ?></li>
                                                <?php } ?>
                                            </ul>
                                        </td>
                                        <td>
                                            <?php foreach ($data['institute']->institute->instituteCourses[0]->instituteBatches as $keyBatch => $batch) { ?>
                                                
                                                    <?php
//                                                    echo $batch->name . " ";
//                                                    $totalScore = 0;
//                                                    $studentScore = 0;
//                                                    foreach ($batch->moduleAssignments as $assignmentKey => $assignment) {
//                                                        foreach ($assignment->moduleAssignmentStudentScores as $scoreKey => $score) {
//                                                            $totalScore = $totalScore + $score->total_score;
//                                                            $studentScore = $studentScore + $score->student_score;
//                                                        }
//                                                    }
//                                                    echo $totalScore . " out of " . $studentScore;
                                                    ?>
                                                
            <?php } ?>
                                                
                                            <?php foreach ($data['institute']->institute->instituteCourses[0]->instituteBatches as $keyBatch => $batch) { ?>
                                                
                                            <div class="bar_graph" id="chartContainerscore<?php echo $batch->id;?>" style="height: 200px; width: 100%;"></div>
                                            
                                            
                                                
                                            <?php } ?>
                                        </td>
                                        <td>
                                            <?php foreach ($data['institute']->institute->instituteCourses[0]->instituteBatches as $keyBatch => $batch) { ?>
                                                
                                            <div class="bar_graph" id="chartContainerunivscore<?php echo $batch->id;?>" style="height: 200px; width: 100%;"></div>
                                            
                                            
                                                
                                            <?php } ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                        </div>
                        <div class="contact_now">
                            <h2>One Point Contact:</h2>
                            <span class="contact_img"></span>
                            <a href="javascript:void(0);">support.xyz@mbatrek.com</a>
                        </div>
                    </div>
                </div> 
            </div> 
        </div>
    </div>
</section> 