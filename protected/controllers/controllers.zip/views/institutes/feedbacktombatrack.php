<section class="banner_area feedbackstudenttombatrack">
    <div class="container">
        <h2>You are always a student, never a master. You have to keep moving forward</h2>
        <span>- Conrad Hall</span>
    </div>
</section>    

<section class="industrial_portal intrection_faclty">
    <div class="container">
        <div class="row">
            <?php echo $this->renderPartial("left_menu",array('data'=>$data));?>
            <div class="col-md-9 col-sm-8 col-xs-12">
                <div class="right_sidebar institue_consoldate">
                    <div class="new_heading">
                        <h3>Ratings Given By Students To MBAtrek Modules (Consolidated)</h3>
                        <select>
                            <option>2016-2018</option>
                            <option>2016-2018</option>
                            <option>2016-2018</option>
                        </select>
                    </div>
                    <div class="module_progess institue_consoldate_mbtreck">
                        <div class="session_table">
                            <table class="col-md-12 table-bordered">
                                <thead>
                                    <tr>
                                        <th class="first_th">S.No.</th>
                                        <th class="agenda_th" >Criterion</th>
                                        <th class="score_obtain">Ratings Given By Students To MBAtrek (Low To High)</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td class="first_td"></td>
                                        <td></td>
                                        <td class="inner_value">
                                            <table class="inner_progresss">
                                                <tbody>
                                                    <tr>
                                                        <td class="first_td Very_low">
                                                            <span class="progess_level">1</span>
                                                            <span class="progess_info">Not Valuable at all<span>
                                                                    </td>
                                                                    <td class="low_2">
                                                                        <span class="progess_level">2</span>
                                                                        <span class="progess_info">Little Valuable<span>
                                                                                </td>
                                                                                <td class="Moderate">
                                                                                    <span class="progess_level">3</span>
                                                                                    <span class="progess_info"> Moderately Valuable<span>
                                                                                            </td>
                                                                                            <td class="High_4">
                                                                                                <span class="progess_level">4</span>
                                                                                                <span class="progess_info"> Highly </br>Valuable<span>
                                                                                                        </td>
                                                                                                        <td class="Very_high">
                                                                                                            <span class="progess_level">5</span>
                                                                                                            <span class="progess_info"> Very Highly Valuable<span>
                                                                                                                    </td>
                                                                                                                    </tr>
                                                                                                                    </tbody>
                                                                                                                    </table>
                                                                                                                    </td>
                                                                                                                    </tr>
                                                                                                                    <tr>
                                                                                                                        <td class="first_td">1</td>
                                                                                                                        <td><span class="scrore_td">Understanding of concepts  and its practical applications</span></td>
                                                                                                                        <td class="inner_value">
                                                                                                                            <table class="inner_progresss">
                                                                                                                                <tbody>
                                                                                                                                    <tr>
                                                                                                                                        <td class="first_td Very_low"></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                    </tr>
                                                                                                                                </tbody>
                                                                                                                            </table>
                                                                                                                        </td>
                                                                                                                    </tr>
                                                                                                                    <tr>
                                                                                                                        <td class="first_td">2</td>
                                                                                                                        <td><span class="scrore_td">Enhancing the classroom learning with global industry related interfaces</span></td>
                                                                                                                        <td class="inner_value">
                                                                                                                            <table class="inner_progresss">
                                                                                                                                <tbody>
                                                                                                                                    <tr>
                                                                                                                                        <td class="first_td"></td>
                                                                                                                                        <td class="low_2"></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                    </tr>
                                                                                                                                </tbody>
                                                                                                                            </table>
                                                                                                                        </td>
                                                                                                                    </tr>
                                                                                                                    <tr>
                                                                                                                        <td class="first_td">3</td>
                                                                                                                        <td><span class="scrore_td">Handling of queries by life coach</span></td>
                                                                                                                        <td class="inner_value">
                                                                                                                            <table class="inner_progresss">
                                                                                                                                <tbody>
                                                                                                                                    <tr>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class="Very_high"></td>
                                                                                                                                    </tr>
                                                                                                                                </tbody>
                                                                                                                            </table>
                                                                                                                        </td>
                                                                                                                    </tr>
                                                                                                                    <tr>
                                                                                                                        <td class="first_td">4</td>
                                                                                                                        <td><span class="scrore_td">Delivery of content by life coach</span></td>
                                                                                                                        <td class="inner_value">
                                                                                                                            <table class="inner_progresss">
                                                                                                                                <tbody>
                                                                                                                                    <tr>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class="Moderate"></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                    </tr>
                                                                                                                                </tbody>
                                                                                                                            </table>
                                                                                                                        </td>
                                                                                                                    </tr>
                                                                                                                    <tr>
                                                                                                                        <td class="first_td">5</td>
                                                                                                                        <td><span class="scrore_td">Content / program material imparted during program</span></td>
                                                                                                                        <td class="inner_value">
                                                                                                                            <table class="inner_progresss">
                                                                                                                                <tbody>
                                                                                                                                    <tr>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                        <td class="High_4"></td>
                                                                                                                                        <td class=""></td>
                                                                                                                                    </tr>
                                                                                                                                </tbody>
                                                                                                                            </table>
                                                                                                                        </td>
                                                                                                                    </tr>
                                                                                                                    </tbody>
                                                                                                                    </table>
                                                                                                                    </div>
                                                                                                                    </div>
                                                                                                                    </div>

                                                                                                                    </div> 
                                                                                                                    </div>
                                                                                                                    </div>
                                                                                                                    </section>