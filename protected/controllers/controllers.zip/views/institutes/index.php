<?php
$this->breadcrumbs=array(
	'Institutes',
);

$this->menu=array(
	array('label'=>'Create Institutes','url'=>array('create')),
	array('label'=>'Manage Institutes','url'=>array('admin')),
);
?>

<h1>Institutes</h1>

<?php $this->widget('bootstrap.widgets.TbListView',array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
