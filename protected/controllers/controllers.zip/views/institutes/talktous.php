<section class="banner_area talktous">
    <div class="container">
        <h2>You are always a student, never a master. You have to keep moving forward</h2>
        <span>- Conrad Hall</span>
    </div>
</section>    
<section class="industrial_portal intrection_faclty">
    <div class="container">
        <div class="row">
            <?php echo $this->renderPartial("left_menu",array('data'=>$data));?>
            <div class="col-md-9 col-sm-8 col-xs-12">
                <div class="right_sidebar instute_talk_us">
                    <div class="talk_block_bind">
                        <ul class="list-inline list-unstyled">
                           
                                <li class="faclty_talk">
                                     <a href="<?php echo Yii::app()->createUrl('institutes/interactionlanding',array('type'=>1));?>">
                                        <img src="images/talk_faclty.png"/>
                                     </a>
                                    <img class="corner_fold" src="images/talk_corner.png"/>
                                    <h2>Faculty</h2>
                                </li>
                            
                            
                                <li class="placement_talk">
                                    <a href="<?php echo Yii::app()->createUrl('institutes/interactionlanding',array('type'=>2));?>">
                                        <img src="images/talk_placement.png"/>
                                    </a>
                                    <img class="corner_fold" src="images/placement_corner.png"/>
                                    <h2>Placement Cell</h2>
                                </li>
                            
                            
                                <li class="management_talk margin_li0">
                                    <a href="<?php echo Yii::app()->createUrl('institutes/interactionlanding',array('type'=>3));?>">
                                        <img src="images/talk_managment.png"/>
                                    </a>
                                    <img class="corner_fold" src="images/managment_corner.png"/>
                                    <h2>Management</h2>
                                </li>
                            
                            
                                <li class="live_project margin_li0">
                                    <a href="<?php echo Yii::app()->createUrl('institutes/interactionlanding',array('type'=>4));?>">
                                        <img src="images/talk_live_project.png"/>
                                    </a>
                                    <img class="corner_fold" src="images/live_corner.png"/>
                                    <h2>
                                        -  Live Projects</br>
                                        -  Internships</br>
                                        -  Placements
                                    </h2>
                                </li>
                            
                        </ul>
                    </div>
                </div>
            </div> 
        </div>
    </div>
</section>