<div class="tower_img">
    <span>- Average Attendance for the Module</span>
   <div id="avgattendance1" style="height: 100px; width: 100px;"></div>
</div>
<div class="tower_img">
    <span>- YTD of average of Modules completed so far</span>
    <img src="images/tower.png"/>
</div>