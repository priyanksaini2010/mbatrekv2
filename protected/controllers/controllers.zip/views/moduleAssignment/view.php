<?php
$int = InstituteBatches::model()->findByPk($_GET['institute_batch_id']);

$this->breadcrumbs=array(
	$int->instituteCourse->institute->name=>array('institutes/admin'),
        $int->instituteCourse->course->name=> array('instituteCourse/admin','institute_id' => $int->instituteCourse->institute->id),
        $int->name => array('instituteBatches/view','institute_course_id' => $int->instituteCourse->course->id,'id'=>$int->id),
	'Manage Assignments',
);

$this->menu=array(
	array('label'=>'Manage Assignment','url'=>array('admin','institute_batch_id'=>$_GET['institute_batch_id'])),
	array('label'=>'Manage Quiz','url'=>array('moduleAssigmentQuiz/admin','institute_batch_id'=>$_GET['institute_batch_id'],'module_assignment_id'=>$model->id)),
);

?>
<h1>Assignment Details</h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
	'data'=>$model,
	'attributes'=>array(
		
		array(
                    'name'=>'module_id',
                    'value' => $model->module->name
                ),
		'title',
		'due_date',
		'close_date',
		'open_date',
		'content',
	),
)); ?>
