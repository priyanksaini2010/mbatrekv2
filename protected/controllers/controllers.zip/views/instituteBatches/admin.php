<?php
$int = InstituteCourse::model()->findByPk($_GET['institute_course_id']);
$this->breadcrumbs=array(
	$int->institute->name=>array('institutes/admin'),
        $int->course->name=> array('instituteCourse/admin','institute_id' => $int->institute->id),
	'Manage',
);

$this->menu=array(
	array('label'=>'Manage Batch','url'=>array('instituteBatches/admin','institute_course_id' => $_GET['institute_course_id'])),
	array('label'=>'Create New Batch','url'=>array('instituteBatches/create','institute_course_id' => $_GET['institute_course_id'])),
);

?>

<h1>Manage Institute Batches</h1>

<?php $this->widget('bootstrap.widgets.TbGridView',array(
	'id'=>'institute-batches-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'name',
		array(
			'class'=>'bootstrap.widgets.TbButtonColumn',
                        'updateButtonUrl' => '$this->grid->controller->createUrl("instituteBatches/update", array("institute_course_id"=>$data->institute_course_id,"id"=>$data->id))',
                        'viewButtonUrl' => '$this->grid->controller->createUrl("instituteBatches/view", array("institute_course_id"=>$data->institute_course_id,"id"=>$data->id))',
                        'template' => "{view}{update}"
		),
	),
)); ?>
