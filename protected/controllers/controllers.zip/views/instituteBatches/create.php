<?php
$this->breadcrumbs=array(
	'Institute Batches'=>array('index'),
	'Create',
);
$int = InstituteCourse::model()->findByPk($_GET['institute_course_id']);
$this->breadcrumbs=array(
	$int->institute->name=>array('institutes/admin'),
        $int->course->name=> array('instituteCourse/admin','institute_id' => $int->institute->id),
        'Manage '.$int->course->name.' Batches' => array('admin','institute_course_id'=>$_GET['institute_course_id']),
	'Create New Batch',
);


$this->menu=array(
	array('label'=>'Manage Batch','url'=>array('instituteBatches/admin','institute_course_id' => $_GET['institute_course_id'])),
	array('label'=>'Create New Batch','url'=>array('instituteBatches/create','institute_course_id' => $_GET['institute_course_id'])),
);
?>

<h1>Create New Batch</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>