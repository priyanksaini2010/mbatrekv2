<?php
$this->breadcrumbs=array(
	'Institute Interaction With Placemnets'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List InstituteInteractionWithPlacemnet','url'=>array('index')),
	array('label'=>'Manage InstituteInteractionWithPlacemnet','url'=>array('admin')),
);
?>

<h1>Create InstituteInteractionWithPlacemnet</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>