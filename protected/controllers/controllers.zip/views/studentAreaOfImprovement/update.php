<?php
$int = InstituteBatches::model()->findByPk($_GET['institute_batch_id']);
$student = Students::model()->findByPk($_GET['student_id']);
$this->breadcrumbs=array(
	$int->instituteCourse->institute->name=>array('institutes/admin'),
        $int->instituteCourse->course->name=> array('instituteCourse/admin','institute_id' => $int->instituteCourse->institute->id),
        $int->name => array('instituteBatches/view','institute_course_id' => $int->instituteCourse->course->id,'id'=>$int->id),
        "Manage Students" => array('students/admin','institute_batch_id' => $int->id),
        $student->name => array('students/viewprofile','institute_batch_id' => $int->id,'id'=>$student->id),
        "Manage Areas of Improement" => array('admin','institute_batch_id'=>$_GET['institute_batch_id'],'student_id'=>$student->id),
	'Update Areas of Improvement',
);

$this->menu=array(
	array('label'=>'Manage Area of improvement','url'=>array('admin','institute_batch_id'=>$_GET['institute_batch_id'],'student_id'=>$student->id)),
	
);

?>

<h1>Update Area Of Improvement For <?php echo ucfirst($student->name);?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>