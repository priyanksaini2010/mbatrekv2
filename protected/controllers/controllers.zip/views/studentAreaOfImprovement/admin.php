<?php
$int = InstituteBatches::model()->findByPk($_GET['institute_batch_id']);
$student = Students::model()->findByPk($_GET['student_id']);
$this->breadcrumbs=array(
	$int->instituteCourse->institute->name=>array('institutes/admin'),
        $int->instituteCourse->course->name=> array('instituteCourse/admin','institute_id' => $int->instituteCourse->institute->id),
        $int->name => array('instituteBatches/view','institute_course_id' => $int->instituteCourse->course->id,'id'=>$int->id),
        "Manage Students" => array('students/admin','institute_batch_id' => $int->id),
        $student->name => array('students/viewprofile','institute_batch_id' => $int->id,'id'=>$student->id),
	'Manage Areas of Improvement',
);

$this->menu=array(
	array('label'=>'Add Area of improvement','url'=>array('create','institute_batch_id'=>$_GET['institute_batch_id'],'student_id'=>$student->id)),
	
);

?>

<h1>Areas Of Improvement For <?php echo ucfirst($student->name);?></h1>


<?php $this->widget('bootstrap.widgets.TbGridView',array(
	'id'=>'student-area-of-improvement-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
//		'id',
//		'student_id',
		'notes',
		array(
			'class'=>'bootstrap.widgets.TbButtonColumn',
                        "template" => "{update}{delete}",
                        "updateButtonUrl" => 'Yii::app()->createUrl("studentAreaOfImprovement/update", array("institute_batch_id" => $_GET[\'institute_batch_id\'],"student_id"=>$_GET[\'student_id\'],"id"=>$data->id))',
		),
	),
)); ?>
