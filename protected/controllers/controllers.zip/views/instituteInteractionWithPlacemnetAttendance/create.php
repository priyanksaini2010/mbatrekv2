<?php
$this->breadcrumbs=array(
	'Institute Interaction With Placemnet Attendances'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List InstituteInteractionWithPlacemnetAttendance','url'=>array('index')),
	array('label'=>'Manage InstituteInteractionWithPlacemnetAttendance','url'=>array('admin')),
);
?>

<h1>Create InstituteInteractionWithPlacemnetAttendance</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>