<?php
$int = InstituteBatches::model()->findByPk($_GET['institute_batch_id']);

$this->breadcrumbs=array(
	$int->instituteCourse->institute->name=>array('institutes/admin'),
        $int->instituteCourse->course->name=> array('instituteCourse/admin','institute_id' => $int->instituteCourse->institute->id),
        $int->name => array('instituteBatches/view','institute_course_id' => $int->instituteCourse->course->id,'id'=>$int->id),
	'Manage Case Studies',
);

$this->menu=array(
        array('label'=>'Manage Case Study','url'=>array('moduleCasestudy/admin','institute_batch_id'=>$_GET['institute_batch_id'])),
        array('label'=>'Create Case Study','url'=>array('moduleCasestudy/create','institute_batch_id'=>$_GET['institute_batch_id'])),
);


?>

<h1>Manage <?php echo  $int->instituteCourse->course->name; ?> - <?php echo  $int->name; ?> Case Study</h1>

<?php $this->widget('bootstrap.widgets.TbGridView',array(
	'id'=>'module-casestudy-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'title',
		array(
			'class'=>'bootstrap.widgets.TbButtonColumn',
                        'template' => "{view}{update}",
                        'updateButtonUrl' => '$this->grid->controller->createUrl("moduleCasestudy/update", array("institute_batch_id"=>$data->institute_batch_id,"id"=>$data->id))',
                        'viewButtonUrl' => '$this->grid->controller->createUrl("moduleCasestudy/view", array("institute_batch_id"=>$data->institute_batch_id,"id"=>$data->id))',
		),
	),
)); ?>
