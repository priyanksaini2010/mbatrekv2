<?php
$int = InstituteBatches::model()->findByPk($_GET['institute_batch_id']);
$assigment = ModuleAssignment::model()->findByPk($_GET['module_assignment_id']);
$this->breadcrumbs=array(
	$int->instituteCourse->institute->name=>array('institutes/admin'),
        $int->instituteCourse->course->name=> array('instituteCourse/admin','institute_id' => $int->instituteCourse->institute->id),
        $int->name => array('instituteBatches/view','institute_course_id' => $int->instituteCourse->course->id,'id'=>$int->id),
        "Manage Assignments" => array('moduleAssignment/admin','institute_batch_id' => $int->id),
        $assigment->title =>array('moduleAssignment/view','institute_batch_id' => $int->id,'id'=>$assigment->id),
	'Add Assignments Questions',
);
$this->menu=array(
        array('label'=>'Manage  Assignment Question','url'=>array('moduleAssigmentQuiz/admin','institute_batch_id'=>$_GET['institute_batch_id'],'module_assignment_id'=>$_GET['module_assignment_id'])),
	array('label'=>'Add Assignment Question','url'=>array('moduleAssigmentQuiz/create','institute_batch_id'=>$_GET['institute_batch_id'],'module_assignment_id'=>$_GET['module_assignment_id'])),
);

?>

<h1>Add Assignment Question</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>