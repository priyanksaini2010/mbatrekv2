<?php
$int = InstituteBatches::model()->findByPk($_GET['institute_batch_id']);
$assigment = ModuleAssignment::model()->findByPk($_GET['module_assignment_id']);
$this->breadcrumbs=array(
	$int->instituteCourse->institute->name=>array('institutes/admin'),
        $int->instituteCourse->course->name=> array('instituteCourse/admin','institute_id' => $int->instituteCourse->institute->id),
        $int->name => array('instituteBatches/view','institute_course_id' => $int->instituteCourse->course->id,'id'=>$int->id),
        "Manage Assignments" => array('moduleAssignment/admin','institute_batch_id' => $int->id),
        $assigment->title =>array('moduleAssignment/view','institute_batch_id' => $int->id,'id'=>$assigment->id),
	'Question Detail',
);

$this->menu=array(
	array('label'=>'Manage  Assignment Question','url'=>array('admin','institute_batch_id'=>$_GET['institute_batch_id'],'module_assignment_id'=>$_GET['module_assignment_id'])),
	array('label'=>'Manage  Answers','url'=>array('moduleAssigjmentQuizAnswer/admin','institute_batch_id'=>$_GET['institute_batch_id'],'module_assignment_id'=>$_GET['module_assignment_id'],'module_assigment_quiz_id'=>$model->id)),
);

?>

<h1>Question Detail</h1>

<?php $this->widget('bootstrap.widgets.TbDetailView',array(
	'data'=>$model,
	'attributes'=>array(
		'question',
		'question_score',
	),
)); ?>
