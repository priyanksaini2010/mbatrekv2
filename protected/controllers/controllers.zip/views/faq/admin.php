<?php
$this->breadcrumbs=array(
	'Faqs'=>array('amin'),
	'Manage',
);

$this->menu=array(
	array('label'=>'Manage Faq','url'=>array('faq/admin')),
	array('label'=>'Add Faq','url'=>array('faq/create')),
);

?>

<h1>Manage Faqs</h1>


<?php $this->widget('bootstrap.widgets.TbGridView',array(
	'id'=>'faq-grid',
	'dataProvider'=>$model->search(),
	'filter'=>$model,
	'columns'=>array(
		'question',
		'answer',
		array(
                    'class'=>'bootstrap.widgets.TbButtonColumn',
                    "template" => "{update}{delete}"
		),
	),
)); ?>
