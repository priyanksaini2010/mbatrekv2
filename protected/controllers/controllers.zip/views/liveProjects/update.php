<?php
$this->breadcrumbs=array(
	'Live Projects'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List LiveProjects','url'=>array('index')),
	array('label'=>'Create LiveProjects','url'=>array('create')),
	array('label'=>'View LiveProjects','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage LiveProjects','url'=>array('admin')),
);
?>

<h1>Update LiveProjects <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>