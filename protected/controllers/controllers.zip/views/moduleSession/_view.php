<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id),array('view','id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('module_id')); ?>:</b>
	<?php echo CHtml::encode($data->module_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('institute_batch_id')); ?>:</b>
	<?php echo CHtml::encode($data->institute_batch_id); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('agenda')); ?>:</b>
	<?php echo CHtml::encode($data->agenda); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('session_plan')); ?>:</b>
	<?php echo CHtml::encode($data->session_plan); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('date')); ?>:</b>
	<?php echo CHtml::encode($data->date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('venue_type')); ?>:</b>
	<?php echo CHtml::encode($data->venue_type); ?>
	<br />


</div>