<div class="student_info_fx institute_portal">
    <a class="student_profile" href="javascript:void(0);">Institute Schedules</a>
    <div class="profile_coantainer">
        <h3 class="fcus_hding">Schedule</h3>
        <div id="content1-1" class="content">
            <ul id="accordion" class="accordion">
                <li>
                    <div class="link">1)  2016 - 2018 <i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <div class="submenu">
                        <a class="pdf_view" href="javascript:void(0);">Click to View</a>
                    </div>
                </li>
                <li>
                    <div class="link">1)  2017 - 2019 <i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <div class="submenu">
                        <a class="pdf_view" href="javascript:void(0);">Click to View</a>
                    </div>
                </li>
                <li>
                    <div class="link">Events <i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <div class="submenu">
                        <a class="pdf_view" href="javascript:void(0);">Click to View</a>
                    </div>
                </li>
                <li>
                    <div class="link">Programs <i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <div class="submenu">
                        <a class="pdf_view" href="javascript:void(0);">Click to View</a>
                    </div>
                </li>
                <li>
                    <div class="link">Module <i class="fa fa-caret-right" aria-hidden="true"></i></div>
                    <div class="submenu">
                        <a class="pdf_view" href="javascript:void(0);">Click to View</a>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>