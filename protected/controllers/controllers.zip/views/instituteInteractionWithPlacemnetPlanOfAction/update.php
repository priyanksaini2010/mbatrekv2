<?php
$this->breadcrumbs=array(
	'Institute Interaction With Placemnet Plan Of Actions'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List InstituteInteractionWithPlacemnetPlanOfAction','url'=>array('index')),
	array('label'=>'Create InstituteInteractionWithPlacemnetPlanOfAction','url'=>array('create')),
	array('label'=>'View InstituteInteractionWithPlacemnetPlanOfAction','url'=>array('view','id'=>$model->id)),
	array('label'=>'Manage InstituteInteractionWithPlacemnetPlanOfAction','url'=>array('admin')),
);
?>

<h1>Update InstituteInteractionWithPlacemnetPlanOfAction <?php echo $model->id; ?></h1>

<?php echo $this->renderPartial('_form',array('model'=>$model)); ?>