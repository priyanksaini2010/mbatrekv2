<?php
$this->breadcrumbs=array(
	'Institute Interaction With Placemnet Plan Of Actions'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List InstituteInteractionWithPlacemnetPlanOfAction','url'=>array('index')),
	array('label'=>'Manage InstituteInteractionWithPlacemnetPlanOfAction','url'=>array('admin')),
);
?>

<h1>Create InstituteInteractionWithPlacemnetPlanOfAction</h1>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>